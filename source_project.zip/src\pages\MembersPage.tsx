import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useMemberStore, type Member } from '../store/useMemberStore';
import {
    Users,
    UserCheck,
    AlertTriangle,
    Zap,
    Search,
    UserPlus,
    ChevronRight,
    Activity,
    LineChart,
    BrainCircuit,
    LayoutDashboard,
    LayoutGrid,
    Heart,
    BarChart2,
    Database,
    MoreHorizontal,
    XCircle,
    ChevronLeft,
    CheckCircle2,
    type LucideIcon
} from 'lucide-react';
import { toast } from 'sonner';
import { isSameDay } from 'date-fns';
import { MemberAutomationDashboard } from '../components/MemberAutomationPanel';
import { useMemberAutomation } from '../components/MemberAutomationEngine';
import { GymTrafficAnalysis } from '../components/GymTrafficAnalysis';
import { IntelligenceConsole } from '../components/IntelligenceConsole';
import {
    MemberOverviewCharts,
    MemberMessages,
    MemberAnalytics
} from '../components/MemberAdvancedComponents';
import { MemberHealthDashboard } from '../components/MemberHealthTracking';
import { DataQualityDashboard } from '../components/DataQualityPanel';

// --- UTILS ---
const translateStatus = (status: string) => {
    switch (status?.toLowerCase()) {
        case 'active': return 'Hoạt động';
        case 'expired': return 'Hết hạn';
        case 'pending': return 'Chờ duyệt';
        default: return 'Khác';
    }
};

const translateMembership = (type: string) => {
    if (!type) return 'N/A';
    if (type.includes('Gói') || type.includes('Buổi')) return type;
    const t = type.toLowerCase();
    if (t.includes('1 month')) return 'Gói 1 Tháng';
    if (t.includes('3 months')) return 'Gói 3 Tháng';
    if (t.includes('6 months')) return 'Gói 6 Tháng';
    if (t.includes('1 year')) return 'Gói 1 Năm';
    return type;
};

const getMemberRank = (sessionsUsed: number = 0) => {
    if (sessionsUsed >= 200) return { label: 'Legend 🏆', color: 'text-yellow-400 border-yellow-400/30' };
    if (sessionsUsed >= 50) return { label: 'Elite 💎', color: 'text-purple-400 border-purple-400/30' };
    if (sessionsUsed >= 10) return { label: 'Pro 🥇', color: 'text-blue-400 border-blue-400/30' };
    return { label: 'Newbie 🌱', color: 'text-zinc-500 border-zinc-500/30' };
};

export default function MembersPage() {
    const { members, deleteMember, performCheckIn } = useMemberStore();
    const { isEngineRunning } = useMemberAutomation();

    const handleCheckIn = (member: Member) => {
        if (!member) return;

        if (member.sessionsUsed >= member.sessionsTotal) {
            toast.error(`⚠️ ${member.name} đã hết buổi tập! Vui lòng gia hạn.`);
            return;
        }

        if (member.lastCheckIn && member.lastCheckIn !== 'N/A') {
            const lastDate = new Date(member.lastCheckIn);
            const today = new Date();
            if (lastDate.toDateString() === today.toDateString()) {
                toast.error(`⚠️ ${member.name} đã check-in hôm nay rồi!`);
                return;
            }
        }

        performCheckIn(member.id, 'Gym Access');
        toast.success(`✅ Check-in thành công: ${member.name}`);
    };

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const isTablet = typeof window !== 'undefined' && window.innerWidth >= 768 && window.innerWidth < 1024;

    const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'messages' | 'health' | 'automation' | 'analytics' | 'dataquality'>(isMobile ? 'members' : 'overview');
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState<string>('All');
    const [filterType, setFilterType] = useState<string>('All');
    const [sortBy] = useState<'name' | 'joinDate' | 'status'>('name');
    const [sortOrder] = useState<'asc' | 'desc'>('asc');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 8;

    const [selectedMember, setSelectedMember] = useState<Member | null>(null);
    const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [selectedMemberIds, setSelectedMemberIds] = useState<Set<string>>(new Set());

    const safeMembers = useMemo(() => (members || []).filter(m => !!m), [members]);

    const activeMembersCount = safeMembers.filter(m => m.status === 'Active').length;
    const newMembersThisMonth = safeMembers.filter(m => {
        const d = new Date(m.joinDate);
        return !isNaN(d.getTime()) && d.getMonth() === new Date().getMonth();
    }).length;
    const expiredCount = safeMembers.filter(m => m.status === 'Expired').length;

    const filteredMembers = useMemo(() => {
        const result = safeMembers.filter(m => {
            const sTerm = searchTerm.toLowerCase();
            const matchesSearch = (m.name || '').toLowerCase().includes(sTerm) ||
                (m.phone || '').includes(sTerm) ||
                (m.id || '').toLowerCase().includes(sTerm);

            const statusMatch = filterStatus === 'All' || (m.status || '').toLowerCase() === filterStatus.toLowerCase();
            const typeMatch = filterType === 'All' || m.membershipType === filterType;
            return matchesSearch && statusMatch && typeMatch;
        });

        result.sort((a, b) => {
            let cmp = 0;
            if (sortBy === 'name') cmp = (a.name || '').localeCompare(b.name || '');
            if (sortBy === 'status') cmp = (a.status || '').localeCompare(b.status || '');
            if (sortBy === 'joinDate') {
                const da = new Date(a.joinDate).getTime() || 0;
                const db = new Date(b.joinDate).getTime() || 0;
                cmp = da - db;
            }
            return sortOrder === 'asc' ? cmp : -cmp;
        });

        return result;
    }, [safeMembers, searchTerm, filterStatus, filterType, sortBy, sortOrder]);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, filterStatus, filterType]);

    const totalPages = Math.ceil(filteredMembers.length / itemsPerPage);

    const paginatedMembers = useMemo(() => {
        return filteredMembers.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    }, [filteredMembers, currentPage, itemsPerPage]);

    const handleBulkDelete = () => {
        if (window.confirm(`Xóa ${selectedMemberIds.size} hội viên này?`)) {
            selectedMemberIds.forEach(id => deleteMember(id));
            setSelectedMemberIds(new Set());
            toast.success("Đã xóa hội viên đã chọn");
        }
    };

    return (
        <div
            className="min-h-screen bg-[#030014] text-white flex flex-col md:flex-row animate-fade-in"
            data-device={isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop'}
        >
            {/* SIDEBAR (Desktop/Tablet) */}
            {!isMobile && (
                <div className={`${isTablet ? 'w-24' : 'w-72'} bg-[#050505] border-r border-white/5 flex flex-col transition-all duration-500`}>
                    <div className="p-8 border-b border-white/5">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center font-black italic shadow-lg shadow-primary/20">M</div>
                            {!isTablet && (
                                <div>
                                    <h2 className="text-sm font-black italic tracking-tighter text-white">MODUN GYM</h2>
                                    <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Antigravity OS</p>
                                </div>
                            )}
                        </div>
                    </div>

                    <nav className="flex-1 p-6 space-y-4">
                        <SideNavButton
                            active={activeTab === 'overview'}
                            onClick={() => setActiveTab('overview')}
                            icon={LayoutGrid}
                            label="Dashboard"
                            collapsed={isTablet}
                        />
                        <SideNavButton
                            active={activeTab === 'members'}
                            onClick={() => setActiveTab('members')}
                            icon={Users}
                            label="Hội Viên"
                            collapsed={isTablet}
                        />
                        <SideNavButton
                            active={activeTab === 'health'}
                            onClick={() => setActiveTab('health')}
                            icon={Heart}
                            label="Bio Metrics"
                            collapsed={isTablet}
                        />
                        <div className="pt-4 mt-4 border-t border-white/5">
                            <SideNavButton
                                active={activeTab === 'automation'}
                                onClick={() => setActiveTab('automation')}
                                icon={BrainCircuit}
                                label="AI Engine"
                                collapsed={isTablet}
                                status={isEngineRunning ? 'on' : 'off'}
                            />
                            <SideNavButton
                                active={activeTab === 'analytics'}
                                onClick={() => setActiveTab('analytics')}
                                icon={BarChart2}
                                label="Báo Cáo"
                                collapsed={isTablet}
                            />
                            <SideNavButton
                                active={activeTab === 'dataquality'}
                                onClick={() => setActiveTab('dataquality')}
                                icon={Database}
                                label="Data Health"
                                collapsed={isTablet}
                            />
                        </div>
                    </nav>

                    <div className="p-6 border-t border-white/5">
                        <div className={`bg-zinc-900/50 rounded-2xl p-4 flex items-center ${isTablet ? 'justify-center' : 'gap-3'}`}>
                            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-[10px] font-black">AD</div>
                            {!isTablet && (
                                <div className="flex-1 min-w-0">
                                    <p className="text-xs font-black truncate">ADMIN OS</p>
                                    <div className="flex items-center gap-1">
                                        <div className="w-1 h-1 rounded-full bg-green-500 animate-pulse" />
                                        <p className="text-[9px] font-bold text-green-500">READY</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* MAIN CONTENT */}
            <div className="flex-1 flex flex-col h-full overflow-hidden">
                {/* HEADER - Only show on Desktop/Tablet */}
                {!isMobile && (
                    <header className="h-20 bg-[#030014]/60 backdrop-blur-2xl border-b border-white/5 flex items-center justify-between px-8 z-50 relative overflow-hidden">
                        <div className="flex items-center gap-4 flex-1 relative z-10">
                            <div className="relative w-full max-w-lg hidden md:block group">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-primary transition-colors" size={18} />
                                <input
                                    placeholder="Tìm kiếm hội viên (Tên, SĐT, ID)..."
                                    className="w-full bg-black/40 border border-white/5 rounded-2xl px-12 py-3 text-sm font-bold focus:outline-none focus:border-primary/50 transition-all placeholder:text-zinc-700 shadow-inner"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="flex items-center gap-4 relative z-10">
                            {selectedMemberIds.size > 0 && (
                                <motion.button
                                    initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
                                    onClick={handleBulkDelete}
                                    className="px-4 py-2 bg-red-500/10 text-red-500 rounded-xl text-[9px] font-black uppercase tracking-widest border border-red-500/20 hover:bg-red-500 hover:text-white transition-all shadow-lg shadow-red-500/10"
                                >
                                    Xóa ({selectedMemberIds.size})
                                </motion.button>
                            )}
                            <button
                                onClick={() => setIsAddMemberModalOpen(true)}
                                className="px-6 py-3 bg-primary text-white rounded-2xl flex items-center gap-3 shadow-xl shadow-primary/30 active:scale-90 transition-all"
                            >
                                <UserPlus size={20} strokeWidth={3} />
                                <span className="text-[11px] font-[900] uppercase tracking-widest italic">THÊM MỚI</span>
                            </button>
                        </div>
                    </header>
                )}

                {/* MOBILE PREMIUM TOP BAR & TABS */}
                {isMobile && (
                    <div className="sticky top-0 z-50 bg-[#030014]/60 backdrop-blur-3xl border-b border-white/5 relative overflow-hidden">
                        {/* Mesh Gradient Background Decorative */}
                        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/5 via-transparent to-blue-500/5 pointer-events-none" />

                        <div className="px-6 py-5 flex items-center justify-between relative z-10 gap-4">
                            <h2 className="text-2xl font-[1000] italic tracking-tighter text-white uppercase drop-shadow-2xl whitespace-nowrap shrink-0">Hội Viên</h2>
                            <div className="flex-1" />
                            <button
                                onClick={() => setIsAddMemberModalOpen(true)}
                                className="w-12 h-12 flex items-center justify-center bg-primary text-white rounded-2xl shadow-lg shadow-primary/20 active:scale-90 transition-all shrink-0"
                            >
                                <UserPlus size={22} strokeWidth={3} />
                            </button>
                        </div>
                        <div className="px-4 pb-4 flex items-center gap-1 overflow-x-auto no-scrollbar scroll-smooth relative z-10">
                            {[
                                { id: 'members', label: 'D.Sách', icon: Users },
                                { id: 'overview', label: 'T.Kế', icon: LayoutGrid },
                                { id: 'health', label: 'S.Trắc', icon: Heart },
                                { id: 'automation', label: 'AI', icon: BrainCircuit },
                                { id: 'analytics', label: 'Báo Cáo', icon: LineChart }
                            ].map(tab => {
                                const Icon = tab.icon;
                                const isActive = activeTab === tab.id;
                                return (
                                    <button
                                        key={tab.id}
                                        onClick={() => setActiveTab(tab.id as any)}
                                        className={`px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-tight whitespace-nowrap transition-all relative flex items-center gap-1.5
                                            ${isActive ? 'text-white' : 'text-zinc-500 hover:text-white/80'}`}
                                    >
                                        {isActive && (
                                            <motion.div
                                                layoutId="activeTabBg"
                                                className="absolute inset-0 bg-primary/20 border border-primary/30 rounded-xl shadow-[0_0_20px_rgba(168,85,247,0.15)]"
                                                transition={{ type: "spring", bounce: 0.15, duration: 0.6 }}
                                            />
                                        )}
                                        <Icon size={12} className={isActive ? 'text-primary' : 'text-zinc-600'} />
                                        <span className="relative z-10">{tab.label}</span>
                                    </button>
                                );
                            })}
                        </div>
                        {/* Scroll hint gradient */}
                        <div className="absolute right-0 top-1/2 bottom-4 w-8 bg-gradient-to-l from-[#030014] to-transparent pointer-events-none z-20" />
                    </div>
                )}

                {/* CONTENT AREA */}
                <main className={`flex-1 overflow-y-auto overflow-x-hidden ${isMobile ? 'p-4 pb-32' : 'p-8'} no-scrollbar scroll-smooth bg-[#030014]`}>
                    <AnimatePresence mode="wait">
                        {activeTab === 'overview' && (
                            <motion.div key="overview" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-10">
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                    <StatCard label="Tổng Hội Viên" value={safeMembers.length} icon={Users} color="text-blue-500" sub="Cơ sở dữ liệu" />
                                    <StatCard label="Đang Hoạt Động" value={activeMembersCount} icon={UserCheck} color="text-green-500" sub="75% tỉ lệ" trend="+12%" />
                                    <StatCard label="Hết Hạn / Rủi Ro" value={expiredCount} icon={AlertTriangle} color="text-red-500" sub="Cần chăm sóc" trend="-5%" />
                                    <StatCard label="Gia Nhập Mới" value={newMembersThisMonth} icon={Zap} color="text-purple-500" sub="Tháng này" trend="+24%" />
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                                    <div className="lg:col-span-8 bg-zinc-900/20 border border-white/5 rounded-[3rem] p-10 shadow-2xl overflow-hidden relative group">
                                        <div className="absolute top-0 right-0 p-10 opacity-[0.03] -rotate-12 group-hover:opacity-10 transition-opacity">
                                            <BarChart2 size={240} />
                                        </div>
                                        <div className="flex items-center justify-between mb-10 relative z-10">
                                            <h3 className="text-xl font-[900] text-white italic uppercase tracking-tighter flex items-center gap-3">
                                                <Activity className="text-primary" size={24} strokeWidth={3} /> PERFORMANCE OVERVIEW
                                            </h3>
                                            <div className="flex items-center gap-2 px-4 py-2 bg-black/40 rounded-full border border-white/5 text-[9px] font-black text-zinc-500 uppercase tracking-widest">REAL-TIME DATA</div>
                                        </div>
                                        <div className="h-[400px]">
                                            <MemberOverviewCharts />
                                        </div>
                                    </div>
                                    <div className="lg:col-span-4 space-y-8">
                                        <GymTrafficAnalysis />
                                        <div className="bg-primary/5 border border-primary/20 rounded-[2.5rem] p-8 relative overflow-hidden group">
                                            <Zap className="absolute -right-4 -bottom-4 text-primary/10 rotate-12 transition-transform duration-700 group-hover:scale-125 group-hover:rotate-0" size={160} />
                                            <h4 className="text-[10px] font-black text-primary uppercase tracking-[0.4em] mb-4">AI PREDICTION</h4>
                                            <p className="text-xl font-black text-white italic leading-tight mb-6">Lưu lượng dự kiến tăng <span className="text-primary">15%</span> vào khung giờ 18h tối nay.</p>
                                            <button className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest italic transition-all">CHI TIẾT DỰ BÁO</button>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'members' && (
                            <motion.div key="members" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
                                {/* Toolbar */}
                                <div className="flex flex-col gap-6 border-b border-white/5 pb-6">
                                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                                        <div className="relative w-full md:w-96 group">
                                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-primary transition-colors" size={18} />
                                            <input
                                                placeholder="Tìm kiếm hội viên..."
                                                className="w-full bg-white/5 border border-white/5 rounded-xl pl-12 pr-4 py-3 text-sm font-medium text-white placeholder:text-zinc-600 focus:border-primary/50 focus:bg-white/10 transition-all outline-none"
                                                value={searchTerm}
                                                onChange={e => setSearchTerm(e.target.value)}
                                            />
                                        </div>

                                        <div className="flex items-center gap-3 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 no-scrollbar">
                                            <FilterGroup label="STATUS" value={filterStatus} onChange={setFilterStatus} options={['All', 'Active', 'Expired', 'Pending']} />
                                            <FilterGroup label="PACKAGE" value={filterType} onChange={setFilterType} options={['All', '1 Month', '3 Months', '6 Months', '1 Year']} />

                                            <div className="w-px h-8 bg-white/10 mx-2 hidden md:block" />

                                            <div className="flex items-center gap-1">
                                                <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition-all"><ChevronLeft size={18} /></button>
                                                <span className="text-xs font-bold text-zinc-500 min-w-[30px] text-center">{currentPage} / {totalPages || 1}</span>
                                                <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage >= totalPages} className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition-all disabled:opacity-30"><ChevronRight size={18} /></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* List */}
                                <div className={`grid ${isMobile ? 'grid-cols-1' : isTablet ? 'grid-cols-2' : 'grid-cols-1'} gap-2`}>
                                    <AnimatePresence mode="popLayout">
                                        {paginatedMembers.map((member, idx) => (
                                            <MemberRow
                                                key={member.id}
                                                member={member}
                                                index={idx}
                                                view={isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop'}
                                                selected={selectedMemberIds.has(member.id)}
                                                onSelect={() => {
                                                    const nextSet = new Set(selectedMemberIds);
                                                    if (nextSet.has(member.id)) nextSet.delete(member.id);
                                                    else nextSet.add(member.id);
                                                    setSelectedMemberIds(nextSet);
                                                }}
                                                onAction={(action: 'edit' | 'health' | 'more') => {
                                                    setSelectedMember(member);
                                                    if (action === 'edit') setIsEditModalOpen(true);
                                                    if (action === 'health') setActiveTab('health');
                                                }}
                                                onCheckIn={() => handleCheckIn(member)}
                                            />
                                        ))}
                                    </AnimatePresence>

                                    {paginatedMembers.length === 0 && (
                                        <div className="py-24 text-center text-zinc-800 space-y-4 border border-zinc-800/50 rounded-3xl border-dashed">
                                            <Users size={64} strokeWidth={1} className="mx-auto opacity-20" />
                                            <p className="text-xs font-bold uppercase tracking-widest text-zinc-600">No Members Found</p>
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'messages' && <motion.div key="messages" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><MemberMessages /></motion.div>}
                        {activeTab === 'health' && <motion.div key="health" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><MemberHealthDashboard initialMember={selectedMember} /></motion.div>}
                        {activeTab === 'automation' && (
                            <motion.div
                                key="automation"
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -20 }}
                                className="space-y-8"
                            >
                                <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 items-start">
                                    <div className="xl:col-span-2">
                                        <MemberAutomationDashboard />
                                    </div>
                                    <div className="xl:col-span-1">
                                        <IntelligenceConsole />
                                    </div>
                                </div>
                            </motion.div>
                        )}
                        {activeTab === 'analytics' && <motion.div key="analytics" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><MemberAnalytics /></motion.div>}
                        {activeTab === 'dataquality' && <motion.div key="dataquality" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><DataQualityDashboard /></motion.div>}
                    </AnimatePresence>
                </main>

                {/* FLOATING ACTION BOTTOM NAV (MOBILE) */}
                {isMobile && (
                    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-[400px] z-[100]">
                        <nav className="h-16 bg-[#0a0a0f]/80 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] flex items-center justify-around px-2 shadow-2xl shadow-black/50 overflow-hidden relative">
                            <MobileNavButton active={activeTab === 'members'} onClick={() => setActiveTab('members')} icon={Users} label="H.Viên" />
                            <MobileNavButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} icon={LayoutGrid} label="T.Kế" />
                            <MobileNavButton active={activeTab === 'health'} onClick={() => setActiveTab('health')} icon={Heart} label="S.Trắc" />
                            <MobileNavButton active={activeTab === 'automation'} onClick={() => setActiveTab('automation')} icon={BrainCircuit} label="AI" />
                        </nav>
                    </div>
                )}
            </div>

            <AnimatePresence>
                {(isAddMemberModalOpen || isEditModalOpen) && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/95 backdrop-blur-2xl">
                        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                            className="bg-zinc-900/50 w-full max-w-2xl rounded-[3rem] border border-white/10 shadow-2xl overflow-hidden backdrop-blur-3xl">
                            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-black/20">
                                <h3 className="font-[900] text-2xl text-white italic uppercase tracking-tighter">
                                    {isAddMemberModalOpen ? 'GIA NHẬP HỘI VIÊN MỚI' : 'CẬP NHẬT THÔNG TIN'}
                                </h3>
                                <button onClick={() => { setIsAddMemberModalOpen(false); setIsEditModalOpen(false); }} className="p-4 hover:bg-zinc-800 rounded-2xl text-zinc-500 hover:text-white transition-all"><XCircle size={24} strokeWidth={3} /></button>
                            </div>
                            <div className="p-10 space-y-6">
                                <p className="text-sm font-bold text-zinc-500 text-center italic uppercase tracking-widest">Giao diện đăng ký đang được OS tải...</p>
                                <div className="grid grid-cols-2 gap-4">
                                    <button onClick={() => { setIsAddMemberModalOpen(false); setIsEditModalOpen(false); toast.info("Đã hủy"); }} className="p-6 bg-zinc-800 text-white font-black rounded-2xl uppercase italic text-xs">HỦY BỎ</button>
                                    <button onClick={() => { setIsAddMemberModalOpen(false); setIsEditModalOpen(false); toast.success("Đã lưu (Simulated)"); }} className="p-6 bg-primary text-white font-black rounded-2xl uppercase italic text-xs shadow-2xl shadow-primary/20">XÁC NHẬN</button>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

function StatCard({ label, value, icon: Icon, color, sub, trend }: { label: string, value: number, icon: LucideIcon, color: string, sub: string, trend?: string }) {
    return (
        <motion.div
            whileHover={{ y: -8, scale: 1.02 }}
            className={`p-1 bg-[#0c0c0e]/40 border border-white/5 rounded-[2.8rem] shadow-2xl relative overflow-hidden group backdrop-blur-3xl transition-all duration-500 hover:border-primary/20 hover:shadow-primary/5`}
        >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
            <div className="p-8 relative z-10">
                <div className="flex items-start justify-between mb-8">
                    <div className="p-5 bg-black/60 rounded-[1.8rem] shadow-inner border border-white/5 relative group-hover:scale-110 group-hover:border-primary/20 transition-all duration-500">
                        <Icon className={color} size={28} strokeWidth={3} />
                        <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full blur-[4px] opacity-60 ${color.replace('text-', 'bg-')}`} />
                    </div>
                    {trend && (
                        <div className="flex flex-col items-end">
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-green-500/10 rounded-full border border-green-500/10">
                                <Zap size={10} className="text-green-500" fill="currentColor" />
                                <span className="text-[10px] font-black text-green-500 uppercase tracking-widest">{trend}</span>
                            </div>
                            <span className="text-[7px] font-black text-zinc-600 uppercase tracking-[0.2em] leading-none mt-2">VELOCITY ANALYSIS</span>
                        </div>
                    )}
                </div>

                <div className="space-y-2">
                    <div className="text-5xl font-[1000] text-white italic tracking-tighter leading-none mb-1 tabular-nums drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)]">{value}</div>
                    <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                        <div className="text-[9px] uppercase font-black text-zinc-500 tracking-[0.4em] leading-none mb-0.5">{label}</div>
                    </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                    <span className="text-[8px] font-black text-zinc-600 uppercase tracking-[0.3em] italic">{sub}</span>
                    <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center text-zinc-500 group-hover:text-white group-hover:bg-primary transition-all">
                        <ChevronRight size={14} strokeWidth={3} />
                    </div>
                </div>
            </div>
            <div className="absolute -right-10 -bottom-10 opacity-[0.02] group-hover:opacity-[0.05] transition-opacity duration-700 pointer-events-none rotate-[25deg] group-hover:scale-110">
                <Icon size={180} />
            </div>
        </motion.div>
    );
}

function SideNavButton({ active, onClick, icon: Icon, label, collapsed, status }: { active: boolean, onClick: () => void, icon: LucideIcon, label: string, collapsed: boolean, status?: 'on' | 'off' }) {
    return (
        <button
            onClick={onClick}
            className={`w-full flex items-center transition-all duration-300 relative group overflow-hidden
                ${collapsed ? 'justify-center p-4 rounded-2xl' : 'gap-4 px-5 py-4 rounded-2xl'}
                ${active ? 'bg-primary text-white shadow-xl shadow-primary/20' : 'text-zinc-600 hover:text-white hover:bg-white/5'}`}
        >
            <div className="relative shrink-0">
                <Icon size={20} strokeWidth={active ? 3 : 2} />
                {status && (
                    <span className={`absolute -top-1 -right-1 w-2 h-2 rounded-full border border-zinc-900 ${status === 'on' ? 'bg-green-500' : 'bg-red-500'} ${active ? 'animate-pulse' : ''}`} />
                )}
            </div>
            {!collapsed && <span className="text-[13px] font-[900] uppercase italic tracking-widest text-left">{label}</span>}
            {active && !collapsed && <div className="ml-auto w-1 h-1 rounded-full bg-white shadow-2xl" />}
        </button>
    );
}



function MobileNavButton({ active, onClick, icon: Icon, label }: { active: boolean, onClick: () => void, icon: LucideIcon, label: string }) {
    return (
        <button
            onClick={onClick}
            className={`flex flex-col items-center gap-1 transition-all duration-300 relative z-10 ${active ? 'text-primary' : 'text-zinc-500'}`}
        >
            <div className={`p-2 rounded-xl transition-all ${active ? 'bg-primary/10 scale-110' : ''}`}>
                <Icon size={18} strokeWidth={active ? 3 : 2} />
            </div>
            <span className={`text-[8px] font-black uppercase tracking-tight ${active ? 'opacity-100' : 'opacity-40'}`}>{label}</span>
            {active && (
                <motion.div layoutId="nav-indicator-members" className="absolute -bottom-1 w-1 h-1 rounded-full bg-primary shadow-[0_0_10px_rgba(168,85,247,0.5)]" />
            )}
        </button>
    );
}

function FilterGroup({ label, value, onChange, options }: { label: string, value: string, onChange: (v: string) => void, options: string[] }) {
    return (
        <div className="flex items-center gap-4 bg-black/40 border border-white/5 rounded-2xl px-5 py-2">
            <span className="text-[9px] font-black text-zinc-700 uppercase tracking-widest">{label}</span>
            <select
                value={value}
                onChange={e => onChange(e.target.value)}
                className="bg-transparent text-[11px] font-[900] text-zinc-200 uppercase italic tracking-wider outline-none cursor-pointer"
            >
                {options.map((opt: string) => (
                    <option key={opt} value={opt} className="bg-zinc-900 text-white">{opt === 'All' ? 'Tất Cả' : opt}</option>
                ))}
            </select>
        </div>
    );
}

function MemberRow({ member, index, view, selected, onSelect, onAction, onCheckIn }: { member: Member, index: number, view: 'mobile' | 'tablet' | 'desktop', selected: boolean, onSelect: () => void, onAction: (action: 'edit' | 'health' | 'more') => void, onCheckIn: () => void }) {
    const rank = getMemberRank(member.sessionsUsed);
    const percentage = Math.min(100, (member.sessionsUsed / member.sessionsTotal) * 100);

    if (view === 'mobile') {
        return (
            <motion.div
                layout
                initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`p-0 bg-[#0c0c0e]/60 backdrop-blur-xl border rounded-[2.2rem] flex flex-col shadow-2xl relative overflow-hidden group mb-4 ${selected ? 'border-primary shadow-primary/20 bg-primary/[0.03]' : 'border-white/5'}`}
                onClick={onSelect}
            >
                <div className={`absolute top-0 right-0 w-32 h-32 blur-[60px] opacity-[0.07] pointer-events-none transition-all ${member.status === 'Active' ? 'bg-primary' : 'bg-red-500'}`} />
                <div className="p-6 relative z-10 flex flex-col gap-6">
                    <div className="flex items-center gap-5">
                        <div className="relative shrink-0">
                            <div className={`absolute inset-[-3px] rounded-[1.3rem] opacity-20 blur-sm ${member.status === 'Active' ? 'bg-primary' : 'bg-red-500'}`} />
                            <img src={member.avatar || `https://ui-avatars.com/api/?name=${member.name}`} className="w-16 h-16 rounded-[1.2rem] object-cover border border-white/10 relative z-10 shadow-lg" alt="" />
                            <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-[3px] border-[#0c0c0e] z-20 flex items-center justify-center shadow-lg ${member.status === 'Active' ? 'bg-primary animate-pulse' : 'bg-red-500'}`}>
                                {member.status === 'Active' ? <UserCheck size={10} className="text-white" /> : <XCircle size={10} className="text-white" />}
                            </div>
                        </div>
                        <div className="flex-1 min-w-0">
                            <h4 className="text-xl font-black italic text-white uppercase truncate tracking-tighter leading-none mb-1.5">{member.name}</h4>
                            <div className="flex items-center gap-2">
                                <span className={`text-[8px] font-black uppercase px-2 py-0.5 border rounded-lg shadow-sm ${rank.color}`}>{rank.label}</span>
                                <span className="text-[10px] text-zinc-500 font-bold tracking-tight">{member.phone}</span>
                            </div>
                        </div>
                    </div>
                    <div className="mt-8 bg-black/40 rounded-[2rem] p-5 border border-white/5 shadow-inner backdrop-blur-md">
                        <div className="flex items-end justify-between mb-3.5">
                            <div>
                                <p className="text-[8px] font-black text-zinc-600 uppercase tracking-[0.3em] mb-1.5">USAGE CAPACITY</p>
                                <div className="flex items-baseline gap-2">
                                    <span className="text-3xl font-black text-white italic tracking-tighter">{member.sessionsUsed}</span>
                                    <span className="text-zinc-700 text-sm font-black uppercase tracking-widest">/ {member.sessionsTotal}</span>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="text-xl font-black text-primary italic leading-none mb-0.5">{percentage.toFixed(0)}%</div>
                            </div>
                        </div>
                        <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden p-[2px] shadow-lg">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${percentage}%` }} transition={{ duration: 1.5, ease: "circOut" }} className="h-full bg-gradient-to-r from-primary via-blue-400 to-primary rounded-full shadow-[0_0_15px_rgba(var(--primary-rgb),0.5)]" />
                        </div>
                    </div>
                    <div className="flex items-center justify-between mt-8">
                        <div>
                            <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest leading-none mb-1 block">Operational Status</span>
                            <div className="flex items-center gap-2">
                                <div className={`w-1.5 h-1.5 rounded-full ${member.status === 'Active' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-500'}`} />
                                <span className={`text-[10px] font-black uppercase tracking-tighter italic ${member.status === 'Active' ? 'text-zinc-300' : 'text-red-400'}`}>
                                    {translateStatus(member.status)} SYSTEM {member.status === 'Active' ? 'ONLINE' : 'LOCKED'}
                                </span>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            {(() => {
                                const isCheckedInToday = !!(member.lastCheckIn && member.lastCheckIn !== 'N/A' && isSameDay(new Date(member.lastCheckIn), new Date()));
                                return (
                                    <button
                                        onClick={(e) => { e.stopPropagation(); onCheckIn(); }}
                                        disabled={isCheckedInToday}
                                        className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl border transition-all text-[10px] font-black uppercase tracking-wider shadow-lg ${isCheckedInToday ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' : 'bg-primary text-white border-primary active:scale-95 shadow-primary/20'}`}
                                    >
                                        {isCheckedInToday ? <CheckCircle2 size={14} strokeWidth={3} /> : <UserCheck size={14} strokeWidth={3} />}
                                        {isCheckedInToday ? 'XONG' : 'IN'}
                                    </button>
                                );
                            })()}
                            <button onClick={(e) => { e.stopPropagation(); onAction('more'); }} className="w-11 h-11 bg-white/[0.03] text-zinc-500 hover:text-white rounded-2xl border border-white/5 transition-all flex items-center justify-center active:scale-90 hover:bg-zinc-800 hover:border-white/10 shadow-sm"><MoreHorizontal size={16} /></button>
                        </div>
                    </div>
                </div>
            </motion.div>
        );
    }

    if (view === 'tablet') {
        const isCheckedInToday = !!(member.lastCheckIn && member.lastCheckIn !== 'N/A' && isSameDay(new Date(member.lastCheckIn), new Date()));
        return (
            <motion.div
                layout
                initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                className={`p-4 bg-zinc-900/30 border border-white/5 rounded-[2rem] flex items-center gap-4 hover:bg-zinc-900/50 transition-all cursor-pointer group shadow-lg ${selected ? 'border-primary/50 bg-primary/5 shadow-primary/5' : ''}`}
                onClick={onSelect}
            >
                <div className="relative" onClick={(e) => { e.stopPropagation(); onAction('health'); }}>
                    <img src={member.avatar || `https://ui-avatars.com/api/?name=${member.name}`} className="w-16 h-16 rounded-[1.2rem] object-cover border border-white/10 group-hover:border-primary/50 transition-all shadow-md" alt="" />
                    <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-[#09090b] ${member.status === 'Active' ? 'bg-green-500' : 'bg-red-500'}`} />
                </div>
                <div className="flex-1 min-w-0">
                    <h4 className="text-lg font-[900] italic text-white uppercase tracking-tighter truncate leading-tight group-hover:text-primary transition-colors">{member.name}</h4>
                    <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-1">{member.membershipType}</p>
                    <div className="flex items-center gap-1.5 mt-2">
                        <span className={`text-[8px] font-black px-1.5 py-0.5 rounded border bg-black/20 ${rank.color}`}>{rank.label}</span>
                    </div>
                </div>
                <div className="flex flex-col items-end gap-2 shrink-0">
                    <button
                        onClick={(e) => { e.stopPropagation(); onCheckIn(); }}
                        disabled={isCheckedInToday}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border transition-all text-[9px] font-black uppercase tracking-wider shadow-lg ${isCheckedInToday ? 'bg-purple-500/20 text-purple-400 border-purple-500/30 cursor-default' : 'bg-primary text-white border-primary cursor-pointer active:scale-90'}`}
                    >
                        {isCheckedInToday ? <CheckCircle2 size={14} strokeWidth={3} /> : <UserCheck size={14} strokeWidth={3} />}
                        {isCheckedInToday ? 'XONG' : 'IN'}
                    </button>
                    <div className="flex items-center gap-1 opacity-50">
                        <div className="w-10 h-1 bg-zinc-800 rounded-full overflow-hidden">
                            <div className="h-full bg-primary" style={{ width: `${percentage}%` }} />
                        </div>
                        <span className="text-[8px] font-mono text-zinc-500">{member.sessionsUsed}/{member.sessionsTotal}</span>
                    </div>
                </div>
            </motion.div>
        );
    }

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.03 }}
            className={`group border-b border-white/5 last:border-0 hover:bg-white/[0.02] p-4 lg:grid grid-cols-12 gap-4 items-center transition-all relative px-8 mx-2 rounded-xl ${selected ? 'bg-primary/5' : ''}`}
            onClick={(e) => {
                if ((e.target as HTMLElement).tagName !== 'BUTTON' && (e.target as HTMLElement).tagName !== 'INPUT') {
                    onSelect();
                }
            }}
        >
            <div className="col-span-1 flex items-center justify-center pr-4">
                <input type="checkbox" checked={selected} onChange={onSelect} className="w-4 h-4 rounded border-white/10 bg-white/5 text-primary focus:ring-primary ring-offset-zinc-900" />
            </div>
            <div className="col-span-3 flex items-center gap-4">
                <div className="relative shrink-0">
                    <img src={member.avatar || `https://ui-avatars.com/api/?name=${member.name}`} className="w-12 h-12 rounded-xl object-cover border border-white/10" alt="" />
                    <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-[#09090b] ${member.status === 'Active' ? 'bg-green-500' : 'bg-red-500'}`} />
                </div>
                <div className="min-w-0">
                    <h4 className="text-sm font-black text-white truncate">{member.name}</h4>
                    <p className="text-[10px] text-zinc-500 font-bold">{member.phone}</p>
                </div>
            </div>
            <div className="col-span-2">
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{translateMembership(member.membershipType)}</span>
            </div>
            <div className="col-span-2 flex flex-col items-center gap-2">
                <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${percentage}%` }} className="h-full bg-primary" />
                </div>
                <span className="text-[9px] font-mono text-zinc-600">{member.sessionsUsed}/{member.sessionsTotal} ({percentage.toFixed(0)}%)</span>
            </div>
            <div className="col-span-2 flex justify-center">
                <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${member.status === 'Active' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                    {translateStatus(member.status)}
                </span>
            </div>
            <div className="col-span-2 flex items-center justify-end gap-2">
                <button onClick={(e) => { e.stopPropagation(); onCheckIn(); }} className="p-2.5 bg-primary/10 text-primary hover:bg-primary hover:text-white rounded-xl transition-all shadow-sm"><UserCheck size={16} /></button>
                <button onClick={(e) => { e.stopPropagation(); onAction('edit'); }} className="p-2.5 bg-white/5 text-zinc-400 hover:text-white rounded-xl transition-all"><MoreHorizontal size={16} /></button>
            </div>
        </motion.div>
    );
}
