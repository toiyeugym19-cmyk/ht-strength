/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
        "./node_modules/konsta/react/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            // Cung cấp các class mà Konsta UI yêu cầu
            fontFamily: {
                ios: ['-apple-system', 'SF Pro Text', 'SF Pro Display', 'system-ui', 'serif'],
                material: ['Roboto', 'system-ui', 'serif'],
                sans: ['Inter', 'sans-serif'],
                serif: ['"Playfair Display"', 'serif'],
            },
            colors: {
                primary: {
                    DEFAULT: '#7000ff',
                    hover: '#8f40ff',
                    glow: 'rgba(112, 0, 255, 0.5)',
                    // Thêm các sắc thái để Konsta không báo lỗi
                    light: '#9f5cff',
                    dark: '#5a00cc',
                },
                bg: {
                    app: '#030014',
                    panel: 'rgba(30, 30, 48, 0.4)',
                    hover: 'rgba(45, 45, 70, 0.6)',
                },
                accent: {
                    DEFAULT: '#00d4ff',
                    glow: 'rgba(0, 212, 255, 0.5)',
                },
                success: '#00ff9d',
                warning: '#ffbf00',
                danger: '#ff0055',
                text: {
                    main: '#ffffff',
                    muted: '#94a3b8',
                }
            },
            boxShadow: {
                'glow-sm': '0 0 10px rgba(112, 0, 255, 0.3)',
                'glow-md': '0 0 20px rgba(112, 0, 255, 0.4)',
                'glow-lg': '0 0 40px rgba(112, 0, 255, 0.5)',
                'neon-cyan': '0 0 10px rgba(0, 212, 255, 0.5)',
            },
            animation: {
                'float': 'float 6s ease-in-out infinite',
                'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
            },
            keyframes: {
                float: {
                    '0%, 100%': { transform: 'translateY(0)' },
                    '50%': { transform: 'translateY(-10px)' },
                }
            }
        },
    },
    plugins: [],
}
