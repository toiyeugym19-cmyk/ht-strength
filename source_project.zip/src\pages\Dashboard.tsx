import { useState, useEffect, useMemo } from 'react';
import type { ExerciseLog } from '../store/useGymStore';
import { useGymStore } from '../store/useGymStore';
import type { DailyHealth } from '../store/useHealthStore';
import { useHealthStore } from '../store/useHealthStore';
import { format, subDays, isSameDay, startOfWeek, addDays } from 'date-fns';
import { vi } from 'date-fns/locale';
import {
    Dumbbell, Flame, Timer, Calendar,
    Target, X, RefreshCw,
    Zap, Droplets, Moon, BrainCircuit,
    ArrowRight, Power, Terminal, type LucideIcon
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import HealthWidget from '../components/HealthWidget';
import { AutomationPanel, AutomationSettings, AutomationLogs } from '../components/AutomationPanel';
import { useAutomationEngine } from '../components/AutomationEngine';
import { useMemberAutomation } from '../components/MemberAutomationEngine';
import { toast } from 'sonner';

// --- TỪ ĐIỂN & VIỆT HÓA TỰ NHIÊN ---
const GREETINGS = {
    morning: "Chào buổi sáng! Nạp năng lượng để bứt phá nào.",
    afternoon: "Đến giờ chiến rồi! Đừng lười biếng.",
    evening: "Kết thúc ngày dài bằng một buổi tập chất lượng nhé.",
    night: "Nghỉ ngơi thôi. Cơ bắp phát triển khi bạn ngủ."
};

const PLAN_LABELS: Record<string, string> = {
    'Push': 'Ngày Đẩy (Ngực/Vai/Tay Sau)',
    'Pull': 'Ngày Kéo (Lưng/Xô/Tay Trước)',
    'Legs': 'Ngày Chân (Mông/Đùi)',
    'Rest': 'Nghỉ Ngơi & Hồi Phục',
    'Upper': 'Thân Trên',
    'Lower': 'Thân Dưới',
    'Cardio': 'Tim Mạch/Chạy Bộ',
    'FullBody': 'Toàn Thân'
};
const PLAN_KEYS = Object.keys(PLAN_LABELS);

// --- LOGIC PHÂN TÍCH ---
const analyzeUserStatus = (logs: ExerciseLog[], dailyStats: Record<string, DailyHealth>) => {
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const stats = dailyStats[todayStr] || {} as DailyHealth;
    const hasWorkoutToday = logs.some(l => l.date === todayStr);

    let advice = "Hãy duy trì sự kiên định!";
    let status = "ready";

    if (!hasWorkoutToday && (stats.sleepHours || 0) > 7) {
        advice = "Bạn đã ngủ đủ giấc. Hôm nay là ngày hoàn hảo để phá kỷ lục PR!";
        status = "peak";
    } else if ((stats.sleepHours || 0) < 5 && (stats.sleepHours || 0) > 0) {
        advice = "Thiếu ngủ rồi. Hãy tập nhẹ hoặc chỉ Cardio thôi nhé.";
        status = "tired";
    } else if (hasWorkoutToday) {
        advice = "Đã hoàn thành mục tiêu hôm nay. Ăn đủ protein nhé!";
        status = "done";
    }

    return { advice, status };
};

export default function Dashboard() {
    const { logs } = useGymStore();
    const { dailyStats, updateStat, syncWithDevice, isSyncing } = useHealthStore();

    const handleQuickSync = async () => {
        // ALWAYS TRIGGER SYNC for demo/real use if button is clicked
        toast.promise(syncWithDevice(), {
            loading: 'Đang kết nối thiết bị & lấy dữ liệu...',
            success: 'Đồng bộ hoàn tất!',
            error: 'Lỗi kết nối'
        });
    };

    const { pendingSuggestions, isEngineRunning, dismissSuggestion } = useAutomationEngine();
    const { pendingTasks, completeTask } = useMemberAutomation();
    const [currentTime, setCurrentTime] = useState(new Date());
    const [activeTool, setActiveTool] = useState<string | null>(null);
    const [showAutomationSettings, setShowAutomationSettings] = useState(false);

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;

    useEffect(() => {
        const timer = setInterval(() => setCurrentTime(new Date()), 60000);
        return () => clearInterval(timer);
    }, []);

    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const todayStats = dailyStats[todayStr] || { steps: 0, sleepHours: 0, waterMl: 0 };
    const hour = currentTime.getHours();
    const greeting = hour < 12 ? GREETINGS.morning : hour < 17 ? GREETINGS.afternoon : hour < 21 ? GREETINGS.evening : GREETINGS.night;

    const { advice } = analyzeUserStatus(logs, dailyStats);

    const streak = useMemo(() => {
        let count = 0;
        let d = new Date();
        while (logs.some(l => isSameDay(new Date(l.date), d))) {
            count++;
            d = subDays(d, 1);
        }
        return count;
    }, [logs]);

    const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
    const weekDays = [...Array(7)].map((_, i) => {
        const d = addDays(weekStart, i);
        return {
            date: d,
            label: format(d, 'EEE', { locale: vi }),
            isToday: isSameDay(d, new Date()),
            hasWorkout: logs.some(l => isSameDay(new Date(l.date), d))
        };
    });

    return (
        <div className={`min-h-screen bg-[#030014] text-white ${isMobile ? 'pb-32' : 'p-10'} space-y-10 animate-fade-in`}>
            {/* HERO: PERFORMANCE MONITOR */}
            <div className={`relative overflow-hidden rounded-[3.5rem] bg-gradient-to-br from-primary/20 via-zinc-900/40 to-black/60 border border-white/10 shadow-3xl shadow-primary/5 group ${isMobile ? 'mx-4 mt-8 p-8' : 'p-16'}`}>
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay pointer-events-none" />
                <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/20 blur-[120px] rounded-full group-hover:bg-primary/30 transition-all duration-1000" />

                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-10">
                    <div className="space-y-6 flex-1">
                        <h1 className={`${isMobile ? 'text-4xl' : 'text-7xl'} font-[1000] text-white italic tracking-tighter leading-[0.9] flex flex-col`}>
                            <span className="bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent">MY PERFORMANCE</span>
                        </h1>
                        <div className="flex flex-wrap gap-4 pt-4">
                            <div className="px-6 py-3 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3 backdrop-blur-xl">
                                <Timer size={16} className="text-zinc-500" />
                                <span className="text-[11px] font-black text-white/80 uppercase tracking-widest">{format(currentTime, 'HH:mm • EEEE, do MMMM', { locale: vi })}</span>
                            </div>
                        </div>
                        <p className="max-w-xl text-lg font-bold text-zinc-400 italic leading-relaxed pt-2">
                            "{greeting} {advice}"
                        </p>
                    </div>

                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col gap-4 w-full md:w-auto">
                        <Link to="/gym" className="w-full">
                            <button className="w-full px-10 py-6 bg-primary text-white font-[900] rounded-[2rem] flex items-center justify-center gap-5 hover:bg-white hover:text-black active:scale-95 transition-all shadow-2xl shadow-primary/40 group/btn overflow-hidden relative">
                                <span className="text-[13px] uppercase tracking-[0.3em] font-black italic relative z-10">KÍCH HOẠT TRAINING</span>
                                <ArrowRight size={20} className="relative z-10 group-hover/btn:translate-x-2 transition-transform" />
                            </button>
                        </Link>
                        {!isMobile && (
                            <button onClick={() => setShowAutomationSettings(true)} className="px-8 py-5 bg-white/5 border border-white/10 text-white font-[900] rounded-2xl flex items-center gap-4 hover:bg-white/10 active:scale-95 transition-all text-sm uppercase tracking-widest italic">
                                <Power size={20} className={isEngineRunning ? 'text-green-500' : 'text-red-500'} strokeWidth={3} /> ENGINE: {isEngineRunning ? 'ON' : 'OFF'}
                            </button>
                        )}
                    </motion.div>
                </div>
            </div>

            <div className={`grid ${isMobile ? 'grid-cols-1' : 'lg:grid-cols-12'} gap-10`}>
                <div className={`${isMobile ? '' : 'lg:col-span-8'} space-y-10`}>
                    {/* KPI BOXES */}
                    <div className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-4'} gap-4`}>
                        <KPICard
                            label="STREAK"
                            value={streak}
                            sub="NGÀY"
                            icon={Flame}
                            color="text-orange-500"
                            onClick={() => toast.info('Tiếp tục luyện tập mỗi ngày để tăng chuỗi!')}
                        />
                        <KPICard
                            label="NƯỚC"
                            value={(todayStats.waterMl / 1000).toFixed(1)}
                            sub="LÍT"
                            icon={Droplets}
                            color="text-blue-400"
                            onClick={() => {
                                updateStat(todayStr, { waterMl: (todayStats.waterMl || 0) + 250 });
                                toast.success('+250ml Nước');
                            }}
                        />
                        <KPICard
                            label="NGỦ"
                            value={todayStats.sleepHours || 0}
                            sub="GIỜ"
                            icon={Moon}
                            color="text-purple-400"
                            onClick={() => {
                                const newVal = Number((todayStats.sleepHours + 0.5).toFixed(1));
                                updateStat(todayStr, { sleepHours: newVal > 24 ? 0 : newVal });
                                toast.success(`Đã cập nhật: ${newVal}h ngủ`);
                            }}
                        />
                        <KPICard
                            label="CALO"
                            value={Math.round((todayStats.steps || 0) * 0.04)}
                            sub="KCAL"
                            icon={Zap}
                            color="text-yellow-400"
                            onClick={handleQuickSync}
                        />
                    </div>

                    {/* NEW: REAL PHONE SYNC BUTTON */}
                    <div className="pt-2">
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleQuickSync}
                            className={`w-full py-5 rounded-[2rem] bg-gradient-to-r from-blue-600 to-primary text-white font-black text-xs uppercase tracking-[.25em] flex items-center justify-center gap-4 shadow-xl shadow-blue-500/20 group relative overflow-hidden transition-all`}
                        >
                            <RefreshCw size={18} className={`${isSyncing ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`} />
                            <span className="relative z-10">Đồng bộ dữ liệu thật từ điện thoại</span>
                            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                            <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-purple-400 blur-lg opacity-20 -z-10 animate-pulse" />
                        </motion.button>
                        <p className="text-center text-[9px] font-bold text-zinc-600 uppercase tracking-widest mt-4">
                            Sử dụng Apple Health / Google Fit • Last sync: {currentTime.toLocaleTimeString()}
                        </p>
                    </div>

                    {/* AI RECOMMENDATIONS */}
                    {pendingSuggestions.length > 0 && (
                        <section className="space-y-6">
                            <div className="flex items-center justify-between">
                                <h3 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] flex items-center gap-3 pl-1">
                                    <BrainCircuit size={14} className="text-primary" /> AI INSIGHTS & SUGGESTIONS
                                </h3>
                                <span className="px-3 py-1 bg-white/5 rounded-full text-[9px] font-black text-zinc-500 border border-white/5 uppercase tracking-widest">
                                    {pendingSuggestions.length} MẪU PHÂN TÍCH
                                </span>
                            </div>
                            <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2'} gap-4`}>
                                {pendingSuggestions.slice(0, 4).map(suggestion => (
                                    <motion.div
                                        key={suggestion.id}
                                        initial={{ opacity: 0, scale: 0.95 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        className={`p-6 rounded-[2.5rem] border backdrop-blur-3xl flex items-start gap-5 group relative overflow-hidden transition-all hover:scale-[1.02]
                                            ${suggestion.priority === 'high' ? 'bg-orange-500/10 border-orange-500/20 shadow-2xl shadow-orange-500/5' : 'bg-zinc-900/30 border-white/5 hover:border-white/10'}`}
                                    >
                                        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-20 transition-opacity">
                                            <Zap size={60} />
                                        </div>
                                        <div className="w-14 h-14 rounded-2xl bg-black/40 flex items-center justify-center text-2xl shrink-0 shadow-inner">
                                            {suggestion.icon === 'dumbbell' ? <Dumbbell size={28} className="text-primary" /> :
                                                suggestion.icon === 'moon' ? <Moon size={28} className="text-purple-500" /> :
                                                    suggestion.icon === 'alert-triangle' ? '⚠️' : '⚡'}
                                        </div>
                                        <div className="flex-1 min-w-0 pr-4">
                                            <h4 className="font-black text-white text-sm italic uppercase tracking-wider mb-2">{suggestion.title}</h4>
                                            <p className="text-xs text-zinc-500 font-bold leading-relaxed line-clamp-2">{suggestion.message}</p>
                                        </div>
                                        <button onClick={() => dismissSuggestion(suggestion.id)} className="absolute top-4 right-4 p-2 text-zinc-800 hover:text-white transition-colors">
                                            <X size={16} strokeWidth={3} />
                                        </button>
                                    </motion.div>
                                ))}
                            </div>
                        </section>
                    )}

                    <div id="health-widget-section">
                        <HealthWidget />
                    </div>

                    {/* MEMBER TASKS (n8n & AUTOMATION OUTPUT) */}
                    {pendingTasks.length > 0 && (
                        <section className="space-y-6">
                            <div className="flex items-center justify-between">
                                <h3 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] flex items-center gap-3 pl-1">
                                    <Target size={14} className="text-blue-500" /> PENDING MEMBER ACTIONS (n8n Output)
                                </h3>
                                <div className="flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                                    <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest italic font-mono">Real-time Stream</span>
                                </div>
                            </div>
                            <div className="space-y-4">
                                {pendingTasks.slice(0, 3).map(task => (
                                    <motion.div
                                        key={task.id}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="p-6 bg-blue-500/5 border border-blue-500/10 rounded-[2.5rem] flex items-center justify-between group hover:bg-blue-500/10 transition-all"
                                    >
                                        <div className="flex items-center gap-5">
                                            <div className="w-12 h-12 rounded-2xl bg-black border border-blue-500/20 flex items-center justify-center font-black text-blue-400 italic">
                                                {task.memberName.substring(0, 2).toUpperCase()}
                                            </div>
                                            <div>
                                                <p className="text-xs font-[900] text-white italic uppercase tracking-widest mb-1">{task.memberName}</p>
                                                <div className="flex items-center gap-3">
                                                    <span className="px-2 py-0.5 bg-zinc-800 rounded-md text-[8px] font-black text-zinc-500 uppercase tracking-widest">{task.type}</span>
                                                    <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">{task.title}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <button onClick={() => { completeTask(task.id); toast.success(`Đã xử lý cho ${task.memberName}`); }} className="p-4 bg-blue-500/20 text-blue-400 hover:bg-blue-500 hover:text-white rounded-2xl transition-all active:scale-90">
                                            <ArrowRight size={18} strokeWidth={3} />
                                        </button>
                                    </motion.div>
                                ))}
                            </div>
                        </section>
                    )}

                    {/* SYSTEM INTELLIGENCE FEED */}
                    <section className="space-y-6">
                        <h3 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] flex items-center gap-3 pl-1">
                            <Terminal size={14} className="text-emerald-500" /> SYSTEM INTELLIGENCE FEED
                        </h3>
                        <div className="bg-zinc-900/30 border border-white/5 rounded-[3rem] p-10 backdrop-blur-3xl overflow-hidden relative">
                            <div className="absolute top-0 right-0 p-10 opacity-5">
                                <Timer size={180} />
                            </div>
                            <AutomationLogs />
                        </div>
                    </section>
                </div>

                <div className={`${isMobile ? '' : 'lg:col-span-4'} space-y-10`}>
                    {/* WEEKLY PLANNER */}
                    <div className="bg-zinc-900/40 border border-white/10 rounded-[3rem] p-10 backdrop-blur-3xl relative overflow-hidden group">
                        <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/10 blur-[60px] rounded-full group-hover:scale-150 transition-transform duration-1000" />
                        <div className="flex items-center justify-between mb-8 relative z-10">
                            <h3 className="text-[10px] font-black text-white uppercase tracking-[0.4em] flex items-center gap-3">
                                <Calendar size={14} className="text-primary" /> WEEKLY PLANNER
                            </h3>
                            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                        </div>
                        <div className="grid grid-cols-7 gap-2 mb-10 relative z-10">
                            {weekDays.map(day => (
                                <div key={day.date.toISOString()} className="flex flex-col items-center gap-3">
                                    <span className={`text-[9px] font-black uppercase tracking-widest ${day.isToday ? 'text-primary' : 'text-zinc-600'}`}>
                                        {day.label}
                                    </span>
                                    <div className={`w-full aspect-square rounded-xl border flex items-center justify-center transition-all
                                        ${day.isToday ? 'bg-primary border-primary shadow-lg shadow-primary/20 scale-110' :
                                            day.hasWorkout ? 'bg-primary/20 border-primary/40' : 'bg-black/40 border-white/5 group-hover:border-white/10'}`}>
                                        {day.hasWorkout && <Zap size={12} className={day.isToday ? 'text-white' : 'text-primary'} fill="currentColor" />}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="space-y-4 relative z-10">
                            {PLAN_KEYS.slice(0, 3).map(key => (
                                <button key={key} className="w-full flex items-center justify-between p-5 bg-black/40 border border-white/5 hover:border-white/20 rounded-2xl transition-all group/plan">
                                    <span className="text-[11px] font-[900] text-zinc-400 uppercase italic tracking-widest group-hover/plan:text-white transition-colors">{PLAN_LABELS[key]}</span>
                                    <ArrowRight size={14} className="text-zinc-800 group-hover/plan:text-primary group-hover/plan:translate-x-1 transition-all" />
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* RECENT ACTIVITY */}
                    <div className="bg-zinc-900/40 border border-white/10 rounded-[3rem] p-8 backdrop-blur-3xl">
                        <h3 className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-8 flex items-center gap-3">
                            <RefreshCw size={14} className="text-primary" /> RECENT ACTIVITY
                        </h3>
                        <div className="space-y-6">
                            {logs.slice(0, 4).map((log, i) => (
                                <div key={i} className="flex gap-4 group cursor-pointer">
                                    <div className="w-0.5 h-auto bg-zinc-800/50 group-hover:bg-primary transition-colors relative">
                                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-zinc-800 border-2 border-[#09090b] group-hover:bg-primary transition-colors" />
                                    </div>
                                    <div className="pt-0.5 pb-2">
                                        <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest mb-1 block">
                                            {format(new Date(log.date), 'dd/MM')}
                                        </span>
                                        <p className="text-[12px] font-black text-white italic uppercase tracking-tighter truncate w-40">
                                            {log.exerciseName || 'Workout Session'}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* AUTOMATION ENGINE PANEL */}
                    <div className="bg-black border border-primary/20 rounded-[3rem] p-10 shadow-3xl shadow-primary/5 group transition-all hover:border-primary/40">
                        <div className="flex items-center justify-between mb-8">
                            <h3 className="text-[10px] font-black text-primary uppercase tracking-[0.5em] italic">Automation Engine</h3>
                            <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center">
                                <Power size={18} className={isEngineRunning ? 'text-green-500' : 'text-red-500'} strokeWidth={3} />
                            </div>
                        </div>
                        <div className="space-y-6">
                            <p className="text-xs text-zinc-500 font-bold leading-relaxed italic">
                                {isEngineRunning ? "Hệ thống đang hoạt động. Các n8n workflows đang quét dữ liệu hội viên theo thời gian thực." : "Hệ thống đã tạm dừng. Các tính năng tự động hóa sẽ không hoạt động."}
                            </p>
                            {isEngineRunning && (
                                <div className="flex items-center gap-4 text-emerald-400">
                                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
                                    <span className="text-[9px] font-black uppercase tracking-[0.3em]">Neural Bridge Active</span>
                                </div>
                            )}
                            <div className="flex gap-4">
                                <button
                                    onClick={() => setShowAutomationSettings(true)}
                                    className="flex-1 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest italic transition-all"
                                >
                                    CẤU HÌNH
                                </button>
                                <button className="flex-1 py-4 bg-primary text-white rounded-2xl text-[10px] font-black uppercase tracking-widest italic active:scale-95 shadow-xl shadow-primary/20 transition-all">
                                    TEST FLOW
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* TOOLBOX: QUICK ACTION */}
                    <div className="flex gap-4">
                        <button onClick={() => setActiveTool('timer')} className="flex-1 p-8 bg-zinc-900/30 border border-white/5 rounded-[2.5rem] hover:bg-zinc-900/50 transition-all group">
                            <Timer size={24} className="text-primary mb-4 group-hover:scale-110 transition-transform" />
                            <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block">CHRONO</span>
                            <span className="text-xs font-black text-white italic uppercase">Timer</span>
                        </button>
                        <button onClick={() => setActiveTool('1rm')} className="flex-1 p-8 bg-zinc-900/30 border border-white/5 rounded-[2.5rem] hover:bg-zinc-900/50 transition-all group">
                            <Dumbbell size={24} className="text-primary mb-4 group-hover:scale-110 transition-transform" />
                            <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block">STRENGTH</span>
                            <span className="text-xs font-black text-white italic uppercase">Estimator</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* MODALS */}
            <AnimatePresence>
                {activeTool && (
                    <ToolModal title={activeTool === 'timer' ? 'CHRONO TIMER' : 'MAX STRENGTH ESTIMATOR'} onClose={() => setActiveTool(null)}>
                        {activeTool === 'timer' ? <TimerTool /> : <OneRMTool />}
                    </ToolModal>
                )}
                {showAutomationSettings && (
                    <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-black/95 backdrop-blur-2xl">
                        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.8, opacity: 0 }}
                            className="bg-zinc-900/50 w-full max-w-4xl rounded-[3.5rem] border border-white/10 shadow-3xl overflow-hidden backdrop-blur-3xl max-h-[90vh] flex flex-col">
                            <div className="p-10 border-b border-white/5 flex justify-between items-center bg-black/20 shrink-0">
                                <div>
                                    <h3 className="font-[1000] text-3xl text-white italic uppercase tracking-tighter">AUTOMATION ENGINE</h3>
                                    <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mt-1">Neural Protocols & n8n Sync</p>
                                </div>
                                <button onClick={() => setShowAutomationSettings(false)} className="p-4 hover:bg-white/10 rounded-2xl text-zinc-500 hover:text-white transition-all"><X size={24} strokeWidth={3} /></button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-10 no-scrollbar">
                                <AutomationSettings />
                                <div className="mt-10 pt-10 border-t border-white/5">
                                    <AutomationPanel />
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

interface KPICardProps {
    label: string;
    value: string | number;
    sub: string;
    icon: LucideIcon;
    color: string;
    onClick?: () => void;
}

function KPICard({ label, value, sub, icon: Icon, color, onClick }: KPICardProps) {
    return (
        <motion.div
            whileHover={{ y: -5, scale: 1.02 }}
            onClick={onClick}
            className={`bg-zinc-900/30 border border-white/5 p-8 rounded-[2.5rem] flex flex-col items-center justify-center text-center transition-all cursor-pointer hover:bg-zinc-900/50 hover:border-white/10 shadow-2xl ${onClick ? 'active:scale-95' : ''}`}
        >
            <div className="p-4 bg-black/40 rounded-2xl mb-6 shadow-inner">
                <Icon className={color} size={24} strokeWidth={3} />
            </div>
            <div className="text-4xl font-[900] text-white italic leading-none mb-3 tracking-tighter">{value}</div>
            <div className="text-[9px] uppercase font-black text-zinc-600 tracking-[0.3em] pl-1">{label} ({sub})</div>
        </motion.div>
    );
}

interface ToolModalProps {
    title: string;
    onClose: () => void;
    children: React.ReactNode;
}

function ToolModal({ title, onClose, children }: ToolModalProps) {
    return (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-black/95 backdrop-blur-2xl">
            <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.8, opacity: 0 }}
                className="bg-zinc-900/50 w-full max-w-md rounded-[3rem] border border-white/10 shadow-2xl overflow-hidden backdrop-blur-3xl">
                <div className="p-8 border-b border-white/5 flex justify-between items-center bg-black/20">
                    <h3 className="font-[900] text-xl text-white italic uppercase tracking-tighter">{title}</h3>
                    <button onClick={onClose} className="p-4 hover:bg-zinc-800 rounded-2xl text-zinc-500 hover:text-white transition-all"><X size={20} strokeWidth={3} /></button>
                </div>
                <div className="p-10">{children}</div>
            </motion.div>
        </div>
    );
}

function TimerTool() {
    const [ms, setMs] = useState(0);
    const [running, setRunning] = useState(false);
    useEffect(() => {
        let int: ReturnType<typeof setInterval>;
        if (running) int = setInterval(() => setMs((p: number) => p + 10), 10);
        return () => { if (int) clearInterval(int); };
    }, [running]);
    const displayTime = format(new Date(ms), 'mm:ss:SS');
    return (
        <div className="text-center space-y-10">
            <div className="text-7xl font-[900] font-mono text-white italic tracking-tighter tabular-nums mb-4">{displayTime}</div>
            <div className="grid grid-cols-2 gap-6">
                <button onClick={() => setRunning(!running)} className={`py-6 rounded-2xl font-[900] uppercase italic tracking-[0.2em] text-xs transition-all active:scale-95 ${running ? 'bg-red-500 text-white shadow-2xl shadow-red-500/20' : 'bg-primary text-white shadow-2xl shadow-primary/20'}`}>
                    {running ? 'STOP' : 'START'}
                </button>
                <button onClick={() => { setRunning(false); setMs(0); }} className="py-6 rounded-2xl bg-zinc-800 text-white font-[900] uppercase italic tracking-[0.2em] text-xs active:scale-95 transition-all">
                    RESET
                </button>
            </div>
        </div>
    );
}

function OneRMTool() {
    const [w, setW] = useState('');
    const [r, setR] = useState('');
    const oneRM = (Number(w) || 0) * (1 + (Number(r) || 0) / 30);
    return (
        <div className="space-y-10">
            <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                    <label className="text-[10px] uppercase font-black text-zinc-600 tracking-widest pl-1">WEIGHT (KG)</label>
                    <input type="number" value={w} onChange={e => setW(e.target.value)} className="w-full bg-black/40 border border-white/5 rounded-2xl p-6 text-white text-center font-black text-xl outline-none focus:border-primary transition-all shadow-inner" placeholder="0" />
                </div>
                <div className="space-y-3">
                    <label className="text-[10px] uppercase font-black text-zinc-600 tracking-widest pl-1">REPS</label>
                    <input type="number" value={r} onChange={e => setR(e.target.value)} className="w-full bg-black/40 border border-white/5 rounded-2xl p-6 text-white text-center font-black text-xl outline-none focus:border-primary transition-all shadow-inner" placeholder="0" />
                </div>
            </div>
            <div className="p-10 bg-primary/10 border border-primary/20 rounded-[2.5rem] text-center shadow-2xl shadow-primary/10">
                <div className="text-[9px] uppercase font-black text-primary tracking-[0.3em] mb-4">ESTIMATED 1-REP MAX</div>
                <div className="text-6xl font-[900] text-primary italic leading-none">{Math.round(oneRM)} <span className="text-xl text-zinc-500 lowercase">kg</span></div>
            </div>
        </div>
    );
}
