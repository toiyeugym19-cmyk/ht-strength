import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.htstrength.gym',
  appName: 'HT Strength Gym',
  webDir: 'dist'
};

export default config;
