import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import {
    Dumbbell,
    Play,
    History,
    Timer,
    Flame,
    Trophy,
    Target
} from 'lucide-react';

import { useGymAppStore } from '../store/useGymAppStore';
import { toast } from 'sonner';
import { X } from 'lucide-react';

// Giả lập dữ liệu bài tập
const WORKOUTS = [
    { id: 1, title: 'Upper Body Blast', exercises: 8, time: '45 min', intensity: 'High', color: 'from-orange-500 to-red-600', calories: 350 },
    { id: 2, title: 'Leg Day Killer', exercises: 6, time: '60 min', intensity: 'Extreme', color: 'from-blue-600 to-indigo-700', calories: 600 },
    { id: 3, title: 'Core Stability', exercises: 12, time: '30 min', intensity: 'Medium', color: 'from-emerald-500 to-teal-600', calories: 250 },
    { id: 4, title: 'Full Body HIIT', exercises: 10, time: '20 min', intensity: 'Extreme', color: 'from-pink-600 to-rose-700', calories: 400 },
];

export default function GymPage() {
    const { workouts, addWorkout } = useGymAppStore();
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const [activeWorkout, setActiveWorkout] = useState<any>(null);
    const [elapsedTime, setElapsedTime] = useState(0);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);

    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    useEffect(() => {
        let interval: any;
        if (activeWorkout) {
            interval = setInterval(() => setElapsedTime(prev => prev + 1), 1000);
        } else {
            setElapsedTime(0);
        }
        return () => clearInterval(interval);
    }, [activeWorkout]);

    const formatTime = (seconds: number) => {
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        return `${h > 0 ? h + ':' : ''}${m < 10 && h > 0 ? '0' + m : m}:${s < 10 ? '0' + s : s}`;
    };

    const handleStartWorkout = (workout: any) => {
        if (activeWorkout) {
            toast.error('BẠN ĐANG TẬP DỞ', { description: 'Hoàn thành bài tập hiện tại trước khi bắt đầu bài mới.' });
            return;
        }
        setActiveWorkout(workout);
        setElapsedTime(0);
        toast.info(`BẮT ĐẦU: ${workout.title.toUpperCase()}`, { icon: <Play /> });
    };

    const handleFinishWorkout = () => {
        if (!activeWorkout) return;

        const durationMinutes = Math.floor(elapsedTime / 60) || 1; // At least 1 min
        addWorkout({
            name: activeWorkout.title,
            date: new Date().toISOString(),
            duration: durationMinutes,
            caloriesBurned: activeWorkout.calories || 300,
            volume: 0,
            prBreaks: 0
        });

        toast.success('HOÀN THÀNH BÀI TẬP', {
            description: `Bạn đã tập được ${durationMinutes} phút. Tuyệt vời!`,
            icon: <Trophy className="text-amber-500" />
        });
        setActiveWorkout(null);
    };

    const totalCalories = workouts.reduce((acc, w) => acc + w.caloriesBurned, 0);
    const totalDuration = workouts.reduce((acc, w) => acc + w.duration, 0);
    const totalHours = (totalDuration / 60).toFixed(1);

    return (
        <div className={`min-h-screen bg-[#030014] ${isMobile ? 'pb-32 pt-4 px-4' : 'p-8'}`}>
            {/* HERO STATS */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                <motion.div
                    initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                    className="col-span-1 md:col-span-2 relative h-[240px] rounded-[2.5rem] overflow-hidden group shadow-2xl border border-white/5"
                >
                    <img
                        src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        alt="Gym"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                    <div className="absolute inset-0 p-8 flex flex-col justify-end">
                        <div className="flex items-center gap-2 mb-2">
                            <div className="px-3 py-1 bg-red-500/80 rounded-full text-[10px] font-black italic tracking-widest text-white backdrop-blur-md">LIVE TRAINING</div>
                        </div>
                        <h2 className="text-4xl font-[1000] text-white italic uppercase tracking-tighter leading-none mb-2">HT-STRENGTH TRAINING</h2>
                        <p className="text-zinc-300 text-sm font-medium">Hệ thống theo dõi tập luyện chuyên nghiệp bản v4.9</p>
                    </div>
                </motion.div>

                <div className="space-y-6">
                    <div className="bg-white/5 border border-white/10 p-6 rounded-[2rem] flex items-center gap-4 group hover:bg-white/10 transition-all cursor-default">
                        <div className="w-14 h-14 rounded-2xl bg-orange-500/20 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform">
                            <Flame size={28} />
                        </div>
                        <div>
                            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest leading-none mb-1">Calories Đốt Cháy</p>
                            <h3 className="text-2xl font-[1000] text-white italic leading-none">{totalCalories.toLocaleString()} <span className="text-[10px] text-zinc-600">KCAL</span></h3>
                        </div>
                    </div>
                    <div className="bg-white/5 border border-white/10 p-6 rounded-[2rem] flex items-center gap-4 group hover:bg-white/10 transition-all cursor-default">
                        <div className="w-14 h-14 rounded-2xl bg-blue-500/20 flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform">
                            <Timer size={28} />
                        </div>
                        <div>
                            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest leading-none mb-1">Thời Gian Tập</p>
                            <h3 className="text-2xl font-[1000] text-white italic leading-none">{totalHours} <span className="text-[10px] text-zinc-600">HOURS</span></h3>
                        </div>
                    </div>
                </div>
            </div>

            {/* QUICK ACTIONS */}
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h3 className="text-xl font-black text-white italic uppercase leading-none">GIÁO ÁN TẬP LUYỆN</h3>
                    <p className="text-zinc-500 text-[10px] font-bold uppercase mt-1 tracking-widest">Dựa trên thể trạng của hội viên</p>
                </div>
                <button
                    onClick={() => setIsHistoryOpen(true)}
                    className="p-3 bg-white/5 rounded-2xl border border-white/10 hover:bg-white/20 active:scale-90 transition-all group"
                >
                    <History size={18} className="text-zinc-400 group-hover:text-primary" />
                </button>
            </div>

            {/* WORKOUT LIST */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {WORKOUTS.map((workout, i) => (
                    <motion.div
                        key={workout.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                        whileHover={{ y: -5 }}
                        className="group relative h-[380px] rounded-[2.5rem] overflow-hidden shadow-xl border border-white/5 cursor-pointer"
                    >
                        <div className={`absolute inset-0 bg-gradient-to-br ${workout.color} opacity-90 transition-all group-hover:opacity-100`} />
                        <div className="absolute -top-4 -right-4 w-32 h-32 bg-white/10 rounded-full blur-3xl group-hover:bg-white/20 transition-all" />

                        <div className="absolute inset-0 p-8 flex flex-col">
                            <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center mb-6 border border-white/30 shadow-inner">
                                <Dumbbell size={28} className="text-white drop-shadow-md" />
                            </div>

                            <h4 className="text-2xl font-[1000] text-white italic uppercase tracking-tighter leading-tight mb-2">{workout.title}</h4>

                            <div className="flex flex-wrap gap-2 mt-2">
                                <span className="px-3 py-1 bg-black/20 rounded-lg text-[9px] font-black text-white/90 backdrop-blur-md border border-white/10 uppercase tracking-widest">{workout.time}</span>
                                <span className="px-3 py-1 bg-black/20 rounded-lg text-[9px] font-black text-white/90 backdrop-blur-md border border-white/10 uppercase tracking-widest">{workout.exercises} BÀI</span>
                            </div>

                            <p className="text-white/60 text-[10px] font-bold uppercase tracking-[0.2em] mt-auto">Cường độ: <span className="text-white">{workout.intensity}</span></p>

                            <button
                                onClick={(e) => { e.stopPropagation(); handleStartWorkout(workout); }}
                                className="mt-6 w-full py-4 bg-white/20 hover:bg-white text-white hover:text-black font-black text-xs uppercase tracking-[0.2em] rounded-2xl backdrop-blur-md border border-white/30 transition-all flex items-center justify-center gap-2 group/btn"
                            >
                                <Play size={16} fill="currentColor" className="group-hover/btn:scale-110 transition-transform" /> BẮT ĐẦU TẬP
                            </button>
                        </div>
                    </motion.div>
                ))}
            </div>

            {/* ACTIVE WORKOUT OVERLAY */}
            <AnimatePresence>
                {activeWorkout && (
                    <motion.div
                        initial={{ opacity: 0, y: 100 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 100 }}
                        className="fixed bottom-24 left-4 right-4 md:left-auto md:right-8 md:w-96 z-[100] bg-zinc-900/90 backdrop-blur-3xl border border-primary/30 rounded-[2.5rem] p-6 shadow-[0_0_50px_rgba(168,85,247,0.3)]"
                    >
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center text-primary animate-pulse">
                                    <Flame size={20} />
                                </div>
                                <div>
                                    <h4 className="text-sm font-black text-white italic uppercase">{activeWorkout.title}</h4>
                                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Đang tập luyện...</p>
                                </div>
                            </div>
                            <div className="text-2xl font-[1000] text-primary italic font-mono">{formatTime(elapsedTime)}</div>
                        </div>
                        <button
                            onClick={handleFinishWorkout}
                            className="w-full py-4 bg-primary text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-primary/40 active:scale-95 transition-all"
                        >
                            HOÀN THÀNH & LƯU
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* HISTORY MODAL */}
            <AnimatePresence>
                {isHistoryOpen && (
                    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsHistoryOpen(false)} className="absolute inset-0 bg-black/80 backdrop-blur-xl" />
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            className="relative w-full max-w-lg bg-[#0c0c0e] rounded-[3rem] border border-white/10 p-8 shadow-2xl overflow-hidden"
                        >
                            <div className="flex items-center justify-between mb-8">
                                <h3 className="text-2xl font-[1000] text-white italic uppercase tracking-tighter">LỊCH SỬ TẬP</h3>
                                <button onClick={() => setIsHistoryOpen(false)} className="p-2 hover:bg-white/5 rounded-full transition-colors"><X size={24} className="text-zinc-500" /></button>
                            </div>

                            <div className="space-y-4 max-h-[60vh] overflow-y-auto no-scrollbar pr-2">
                                {workouts.length === 0 ? (
                                    <div className="py-20 text-center opacity-30">
                                        <History size={48} className="mx-auto mb-4" />
                                        <p className="text-sm font-black uppercase tracking-widest">Chưa có dữ liệu tập luyện</p>
                                    </div>
                                ) : (
                                    workouts.map((w) => (
                                        <div key={w.id} className="p-5 bg-white/[0.03] border border-white/5 rounded-3xl flex items-center justify-between group hover:bg-white/5 transition-all">
                                            <div className="flex items-center gap-4">
                                                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                                                    <Dumbbell size={20} />
                                                </div>
                                                <div>
                                                    <p className="text-sm font-bold text-white uppercase italic leading-none mb-1">{w.name}</p>
                                                    <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest leading-none">{format(new Date(w.date), 'dd/MM/yyyy • HH:mm')}</p>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <div className="text-sm font-black text-primary italic leading-none mb-1">{w.duration} MIN</div>
                                                <div className="text-[9px] text-zinc-600 font-bold uppercase">{w.caloriesBurned} KCAL</div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* ACHIEVEMENTS */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white/5 border border-white/10 rounded-[3rem] p-10 relative overflow-hidden group">
                    <div className="relative z-10">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-12 h-12 bg-amber-500/20 rounded-xl flex items-center justify-center text-amber-500 border border-amber-500/20">
                                <Trophy size={22} />
                            </div>
                            <h3 className="text-xl font-black text-white italic uppercase tracking-tighter">THÀNH TÍCH GẦN ĐÂY</h3>
                        </div>
                        <div className="space-y-4">
                            {[1, 2, 3].map(i => (
                                <div key={i} className="flex items-center justify-between p-4 bg-white/[0.03] border border-white/5 rounded-2xl hover:bg-white/5 transition-colors">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center text-[10px] font-black text-zinc-500">#{i}</div>
                                        <div>
                                            <p className="text-xs font-bold text-white uppercase italic leading-none mb-1">Kỷ Lục Deadlift Mới</p>
                                            <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest leading-none">CẬP NHẬT 2 NGÀY TRƯỚC</p>
                                        </div>
                                    </div>
                                    <span className="text-primary font-black italic">145 KG</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-primary/10 via-transparent to-blue-500/10 border border-white/10 rounded-[3rem] p-10 flex flex-col justify-center items-center text-center relative overflow-hidden group">
                    <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary to-blue-500" />
                    <div className="w-20 h-20 bg-primary/20 rounded-3xl flex items-center justify-center text-primary mb-6 shadow-2xl shadow-primary/20">
                        <Target size={40} />
                    </div>
                    <h3 className="text-3xl font-[1000] text-white italic uppercase tracking-tighter leading-none mb-2">Mục Tiêu Tháng Này</h3>
                    <p className="text-zinc-500 text-sm font-medium mb-8 max-w-[280px]">Giảm 2% tỷ lệ mỡ cơ thể và duy trì khối lượng cơ bắp hiện tại.</p>
                    <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden p-0.5">
                        <div className="h-full bg-primary rounded-full shadow-[0_0_10px_rgba(var(--primary-rgb),0.5)]" style={{ width: '65%' }} />
                    </div>
                    <p className="mt-4 text-[10px] font-black text-primary uppercase tracking-[0.2em]">65% HOÀN THÀNH</p>
                </div>
            </div>
        </div>
    );
}
