import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface ExerciseLog {
    id: string;
    date: string;
    exerciseName: string;
    weight: number;
    reps: number;
    rpe?: number;
}

type GymState = {
    logs: ExerciseLog[];
    addLog: (log: Omit<ExerciseLog, 'id'>) => void;
};

export const useGymStore = create<GymState>()(
    persist(
        (set) => ({
            logs: [
                { id: '1', date: '2025-01-01', exerciseName: 'Bench Press', weight: 100, reps: 5, rpe: 8 },
                { id: '2', date: '2025-01-02', exerciseName: 'Bench Press', weight: 102.5, reps: 5, rpe: 8.5 },
                { id: '3', date: '2025-01-08', exerciseName: 'Bench Press', weight: 105, reps: 4, rpe: 9 },
                { id: '4', date: '2025-01-15', exerciseName: 'Deadlift', weight: 140, reps: 3, rpe: 7 },
            ],
            addLog: (log) => set((state) => ({
                logs: [...state.logs, { ...log, id: crypto.randomUUID() }]
            }))
        }),
        {
            name: 'lifeos-gym-analytics',
        }
    )
);
