import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
    LayoutDashboard,
    Briefcase,
    RefreshCw,
    Search,
    Cpu,
    Sun,
    Moon,
    Users,
    User2,
    BookOpen,
    Dumbbell,
    Sparkles,
    Settings,
    House,
    Library
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from 'sonner';
import CommandPalette from './CommandPalette';

const LINKS = [
    { to: "/", icon: LayoutDashboard, label: "Tổng Quan" },
    { to: "/members", icon: Users, label: "Hội Viên" },
    { to: "/ecosystem", icon: Sparkles, label: "Hệ Sinh Thái" },
    { to: "/gym", icon: Dumbbell, label: "Phòng Gym" },
    { to: "/knowledge", icon: BookOpen, label: "Kiến Thức" },
    { to: "/work", icon: Briefcase, label: "Nhiệm Vụ" },
];

export default function Layout() {
    const location = useLocation();
    const [deviceType, setDeviceType] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
    const [isSyncing, setIsSyncing] = useState(true);
    const [theme, setTheme] = useState<'dark' | 'light'>('dark');

    useEffect(() => {
        const handleResize = () => {
            const w = window.innerWidth;
            if (w < 768) setDeviceType('mobile');
            else if (w < 1024) setDeviceType('tablet');
            else setDeviceType('desktop');
        };
        handleResize();
        window.addEventListener('resize', handleResize);
        setTimeout(() => setIsSyncing(false), 2000);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const isMobile = deviceType === 'mobile';
    const isTablet = deviceType === 'tablet';

    useEffect(() => {
        document.documentElement.setAttribute('data-device', deviceType);
    }, [deviceType]);

    if (isMobile) {
        return (
            <div className="framework7-root safe-areas">
                <div className="flex flex-col h-[100dvh] w-full bg-[#030014] text-white font-sans overflow-hidden" data-device="mobile">
                    <CommandPalette />
                    {location.pathname === '/' && (
                        <MobileHeader isSyncing={isSyncing} onSync={() => setIsSyncing(true)} />
                    )}
                    <div className="flex-1 overflow-y-auto no-scrollbar relative z-10 p-safe-bottom">
                        <div className="animate-fade-in pb-10">
                            <Outlet />
                        </div>
                    </div>
                    <MobileBottomNav />
                    {/* <AutomationMonitor /> */}
                    <Toaster theme="dark" position="top-center" />
                </div>
            </div>
        );
    }

    if (isTablet) {
        return (
            <div className="flex h-[100dvh] w-full bg-[#030014] text-white font-sans overflow-hidden" data-device="tablet">
                <CommandPalette />
                <aside className="w-[80px] bg-[#0a0a0f] border-r border-white/5 flex flex-col items-center py-8 gap-8 shrink-0">
                    <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
                        <Cpu className="text-white" size={24} />
                    </div>
                    <nav className="flex-1 flex flex-col gap-4">
                        {LINKS.map(link => (
                            <NavLink
                                key={link.to}
                                to={link.to}
                                title={link.label}
                                className={({ isActive }) => `w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${isActive ? 'bg-primary text-white shadow-lg shadow-primary/20 scale-110' : 'text-neutral-500 hover:text-white hover:bg-white/5'}`}
                            >
                                <link.icon size={22} />
                            </NavLink>
                        ))}
                    </nav>
                    <div className="mt-auto pb-4">
                        <button className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                            <Settings size={20} />
                        </button>
                    </div>
                </aside>
                <main className="flex-1 flex flex-col overflow-hidden">
                    <Topbar isSyncing={isSyncing} onSync={() => setIsSyncing(true)} theme={theme} toggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} />
                    <div className="flex-1 overflow-y-auto no-scrollbar p-6">
                        <Outlet />
                    </div>
                </main>
                {/* <AutomationMonitor /> */}
                <Toaster theme="dark" position="top-center" />
            </div>
        );
    }

    return (
        <div className="flex h-[100dvh] w-full bg-[#030014] text-white font-sans overflow-hidden" data-device="desktop">
            <CommandPalette />
            <Sidebar />
            <main className="flex-1 flex flex-col overflow-hidden">
                <Topbar isSyncing={isSyncing} onSync={() => setIsSyncing(true)} theme={theme} toggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} />
                <div className="flex-1 overflow-y-auto no-scrollbar p-8">
                    <div className="max-w-7xl mx-auto w-full">
                        <Outlet />
                    </div>
                </div>
            </main>
            {/* <AutomationMonitor /> */}
            <Toaster theme="dark" position="top-center" />
        </div>
    );
}

function Sidebar() {
    return (
        <aside className="w-64 bg-[#0a0a0f] border-r border-white/5 flex flex-col p-6 shrink-0">
            <NavLink to="/" className="flex items-center justify-center mb-8 cursor-pointer hover:opacity-80 active:scale-95 transition-all w-full py-4">
                <img src="/logo-hts.png" alt="HT Strength Training" className="w-[180px] h-auto object-contain rounded-xl bg-white/90 p-2 shadow-lg shadow-red-500/20" />
            </NavLink>
            <nav className="flex-1 space-y-2">
                {LINKS.map(link => (
                    <NavLink key={link.to} to={link.to} className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${isActive ? 'bg-primary/20 text-primary border border-primary/20' : 'text-neutral-500 hover:bg-white/5 hover:text-white'}`}>
                        <link.icon size={18} />
                        <span className="text-sm font-bold uppercase tracking-tight">{link.label}</span>
                    </NavLink>
                ))}
            </nav>
            <div className="mt-auto space-y-6">
                {/* <div className="bg-gradient-to-br from-blue-600/10 to-purple-600/10 rounded-2xl p-4 border border-white/5">
                    <div className="flex items-center gap-2 mb-2">
                        <Sparkles size={14} className="text-blue-400" />
                        <span className="text-[10px] font-black uppercase text-blue-400 tracking-widest">AI Analysis</span>
                    </div>
                    <p className="text-[10px] text-neutral-400 leading-relaxed font-medium">Hệ thống đang theo dõi 43 hội viên...</p>
                </div> */}
                <div className="flex items-center gap-3 p-1">
                    <div className="w-10 h-10 rounded-full bg-neutral-800 border border-white/10" />
                    <div className="flex-1">
                        <p className="text-xs font-bold text-white uppercase">Admin Hùng Phan</p>
                        <p className="text-[10px] text-green-500 font-bold">V4.92 ONLINE</p>
                    </div>
                    <Settings size={16} className="text-neutral-600 hover:text-white cursor-pointer" />
                </div>
            </div>
        </aside>
    );
}

function Topbar({ isSyncing, onSync, theme, toggleTheme }: any) {
    return (
        <header className="h-20 px-8 flex items-center justify-between border-b border-white/5 bg-[#030014]/50 backdrop-blur-xl shrink-0">
            <div className="flex-1 max-w-md relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                <input placeholder="Tìm kiếm nhanh..." className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-12 pr-4 text-sm outline-none focus:border-primary/50 transition-all font-medium" />
            </div>
            <div className="flex items-center gap-4">
                <button onClick={onSync} className="p-2 hover:bg-white/5 rounded-lg transition-colors group">
                    <RefreshCw size={18} className={isSyncing ? 'animate-spin text-primary' : 'text-neutral-400 group-hover:text-white'} />
                </button>
                <button onClick={toggleTheme} className="p-2 hover:bg-white/5 rounded-lg transition-colors text-neutral-400 hover:text-white">
                    {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
                </button>
                <div className="h-6 w-px bg-white/10 mx-2" />
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary/20">
                        <Users size={16} className="text-primary" />
                    </div>
                    <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest hidden lg:block">Quầy Giao Dịch</span>
                </div>
            </div>
        </header>
    );
}

function MobileHeader({ isSyncing, onSync }: any) {
    return (
        <header className="px-6 py-4 flex items-center justify-between border-b border-white/5 bg-[#030014]/80 backdrop-blur-xl shrink-0 sticky top-0 z-50">
            <NavLink to="/" className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-lg shadow-lg shadow-red-500/20">
                    <img src="/logo-hts.png" alt="HTS" className="h-6 w-auto object-contain" />
                </div>
                <div>
                    <h1 className="text-sm font-black text-white italic tracking-tighter uppercase leading-none">HT-STRENGTH</h1>
                    <p className="text-[8px] font-bold text-primary tracking-widest leading-none mt-1">OPERATIONAL</p>
                </div>
            </NavLink>
            <div className="flex items-center gap-2">
                <button onClick={onSync} className="p-2.5 bg-white/5 rounded-xl border border-white/10 active:scale-90 transition-all">
                    <RefreshCw size={18} className={isSyncing ? 'animate-spin text-primary' : 'text-neutral-400'} />
                </button>
            </div>
        </header>
    );
}

function MobileBottomNav() {
    // iOS Style Navigation Icons mapping
    const MAPPING: any = {
        "/": House,
        "/members": User2,
        "/gym": Dumbbell,
        "/knowledge": Library,
        "/work": Briefcase
    };

    const mobileLinks = LINKS.filter(l => l.to !== "/ecosystem");

    return (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-[400px] z-[100]">
            <nav className="h-16 bg-[#0a0a0f]/80 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] flex items-center justify-around px-2 shadow-2xl shadow-black/50 overflow-hidden relative">
                {mobileLinks.map(link => {
                    const Icon = MAPPING[link.to] || link.icon;
                    return (
                        <NavLink
                            key={link.to}
                            to={link.to}
                            className={({ isActive }) => `flex flex-col items-center justify-center p-2 relative z-10 transition-all duration-300 ${isActive ? 'text-primary' : 'text-neutral-500 hover:text-white'}`}
                        >
                            {({ isActive }) => (
                                <>
                                    <Icon
                                        size={24}
                                        strokeWidth={1.5}
                                        fill={isActive ? "currentColor" : "none"}
                                        className={`${isActive ? 'drop-shadow-[0_0_8px_rgba(168,85,247,0.4)]' : ''}`}
                                    />
                                    {isActive && (
                                        <motion.div
                                            layoutId="bottomTab"
                                            className="absolute -bottom-2 w-1.5 h-1.5 bg-primary rounded-full shadow-[0_0_15px_#a855f7]"
                                        />
                                    )}
                                </>
                            )}
                        </NavLink>
                    );
                })}
            </nav>
        </div>
    );
}
