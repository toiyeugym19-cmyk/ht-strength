# Agent Dispatch Queue

## Sam (Backend) — Next Tasks
1. ~~AGT-77: Linear API sync → Convex~~ ✓ DONE (44277da)
2. ~~AGT-72: @mention parsing - backend~~ ✓ DONE (44277da)

**STATUS: All Sam tasks complete. Awaiting new assignments.**

## Leo (Frontend) — Next Tasks
1. AGT-70: Task Detail Page (IN PROGRESS)
2. AGT-71: Message Thread (IN PROGRESS)
3. AGT-73: Notification bell UI (P: Medium)
4. AGT-76: Agent card live status (P: Medium)
