import { useStore } from '../hooks/useStore';
import { useBoardStore } from '../store/useBoardStore';
import { useNutritionStore } from '../store/useNutritionStore';
import { format, subDays, isSameDay, eachDayOfInterval } from 'date-fns';
import {
    LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
    BarChart, Bar, Cell
} from 'recharts';
import { Activity, Flame, Target, TrendingUp, Zap, Calendar, GitPullRequest } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AnalyticsPage() {
    const { gymLogs } = useStore();
    const { tasks: tasksMap } = useBoardStore();
    const { commits: nutritionCommits, goals } = useNutritionStore();

    const tasks = Object.values(tasksMap);

    // Productivity Analytics
    const last7Days = eachDayOfInterval({
        start: subDays(new Date(), 6),
        end: new Date()
    });

    const completionData = last7Days.map(day => {
        const dayTasks = tasks.filter(t => isSameDay(new Date(t.date), day));
        return {
            date: format(day, 'MMM dd'),
            completed: dayTasks.filter(t => t.completed).length,
            total: dayTasks.length
        };
    });

    // Volume Analytics (Gym)
    const volumeData = gymLogs.slice(-7).map(log => ({
        date: format(new Date(log.date), 'MM/dd'),
        volume: log.totalVolume,
        records: log.records
    }));

    // Nutrition Analytics
    const nutritionData = last7Days.map(day => {
        const dayCommits = nutritionCommits.filter(c => isSameDay(new Date(c.date), day));
        return {
            date: format(day, 'MMM dd'),
            calories: dayCommits.reduce((acc, c) => acc + c.calories, 0),
            target: goals.dailyCalories
        };
    });

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const isTablet = typeof window !== 'undefined' && window.innerWidth >= 768 && window.innerWidth < 1024;

    return (
        <div data-device={isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop'} className="space-y-12 pb-32">
            {/* Header */}
            <div className={isMobile ? 'text-center pt-4' : ''}>
                <h1 className={`${isMobile ? 'text-3xl' : 'text-4xl'} font-black text-white italic uppercase tracking-tighter flex items-center ${isMobile ? 'justify-center' : ''} gap-3`}>
                    <TrendingUp className="text-primary" /> PHÂN TÍCH <span className="text-zinc-500">HỆ THỐNG</span>
                </h1>
                <p className="text-text-muted text-[10px] md:text-lg font-[900] uppercase tracking-[0.3em] mt-2">DỮ LIỆU THỰC THI THỜI GIAN THỰC</p>
            </div>

            {/* Quick Stats */}
            <div className={`grid ${isMobile ? 'grid-cols-2' : isTablet ? 'grid-cols-2' : 'grid-cols-4'} gap-4 md:gap-6`}>
                <StatCard
                    label="TỶ LỆ HOÀN THÀNH"
                    value={`${Math.round((tasks.filter(t => t.completed).length / Math.max(1, tasks.length)) * 100)}%`}
                    sub="System Success"
                    icon={<GitPullRequest size={isMobile ? 18 : 20} className="text-blue-400" />}
                />
                <StatCard
                    label="TỔNG VOLUME"
                    value={`${gymLogs.reduce((acc, l) => acc + l.totalVolume, 0).toLocaleString()}kg`}
                    sub="Power Accumulation"
                    icon={<Activity size={isMobile ? 18 : 20} className="text-purple-400" />}
                />
                <StatCard
                    label="CALO TRUNG BÌNH"
                    value={`${Math.round(nutritionCommits.reduce((acc, c) => acc + c.calories, 0) / Math.max(1, nutritionCommits.length))}kcal`}
                    sub="Body Fueling"
                    icon={<Flame size={isMobile ? 18 : 20} className="text-orange-400" />}
                />
                <StatCard
                    label="UPTIME"
                    value="99.9%"
                    sub="Engine Stability"
                    icon={<Zap size={isMobile ? 18 : 20} className="text-green-400" />}
                />
            </div>

            {/* Charts Grid */}
            <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-12'} gap-8`}>
                {/* Work Efficiency */}
                <div className={isMobile ? '' : 'col-span-12 xl:col-span-7'}>
                    <Card title="HIỆU SUẤT CÔNG VIỆC" icon={<Target className="text-blue-400" />}>
                        <div className={`${isMobile ? 'h-60' : 'h-80'} w-full mt-6`}>
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={completionData}>
                                    <defs>
                                        <linearGradient id="colorCompleted" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                                    <XAxis dataKey="date" stroke="#ffffff20" fontSize={8} fontWeight="900" />
                                    <YAxis stroke="#ffffff20" fontSize={8} fontWeight="900" />
                                    <Tooltip
                                        contentStyle={{ backgroundColor: '#0c0c0e', border: '1px solid #ffffff10', borderRadius: '16px', boxShadow: '0 20px 40px rgba(0,0,0,0.5)' }}
                                        itemStyle={{ color: '#fff', fontSize: '10px', fontWeight: '900', textTransform: 'uppercase' }}
                                    />
                                    <Area type="monotone" dataKey="completed" stroke="#3b82f6" fillOpacity={1} fill="url(#colorCompleted)" strokeWidth={isMobile ? 2 : 4} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </div>

                {/* Workout Volume */}
                <div className={isMobile ? '' : 'col-span-12 xl:col-span-5'}>
                    <Card title="CƯỜNG ĐỘ KHỐI LƯỢNG" icon={<Activity className="text-purple-400" />}>
                        <div className={`${isMobile ? 'h-60' : 'h-80'} w-full mt-6`}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={volumeData}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                                    <XAxis dataKey="date" stroke="#ffffff20" fontSize={8} fontWeight="900" />
                                    <YAxis stroke="#ffffff20" fontSize={8} fontWeight="900" />
                                    <Tooltip
                                        contentStyle={{ backgroundColor: '#0c0c0e', border: '1px solid #ffffff10', borderRadius: '16px' }}
                                        cursor={{ fill: '#ffffff05' }}
                                    />
                                    <Bar dataKey="volume" fill="#8b5cf6" radius={[4, 4, 0, 0]}>
                                        {volumeData.map((_, index) => (
                                            <Cell key={`cell-${index}`} fillOpacity={0.4 + (index * 0.08)} />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </div>

                {/* Caloric Trend */}
                <div className={isMobile ? '' : 'col-span-12 xl:col-span-6'}>
                    <Card title="XU HƯỚNG DINH DƯỠNG" icon={<Flame className="text-orange-400" />}>
                        <div className={`${isMobile ? 'h-60' : 'h-80'} w-full mt-6`}>
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={nutritionData}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                                    <XAxis dataKey="date" stroke="#ffffff20" fontSize={8} fontWeight="900" />
                                    <YAxis stroke="#ffffff20" fontSize={8} fontWeight="900" />
                                    <Tooltip
                                        contentStyle={{ backgroundColor: '#0c0c0e', border: '1px solid #ffffff10', borderRadius: '16px' }}
                                    />
                                    <Line type="monotone" dataKey="calories" stroke="#f97316" strokeWidth={isMobile ? 2 : 4} dot={{ fill: '#f97316', r: 4 }} activeDot={{ r: 8 }} />
                                    <Line type="monotone" dataKey="target" stroke="#ffffff10" strokeDasharray="5 5" strokeWidth={2} dot={false} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </div>

                {/* Weekly Heatmap */}
                <div className={isMobile ? '' : 'col-span-12 xl:col-span-6'}>
                    <Card title="MẬT ĐỘ KIÊN TRÌ" icon={<Calendar className="text-green-400" />}>
                        <div className="mt-8 grid grid-cols-7 gap-2">
                            {Array.from({ length: 28 }).map((_, i) => (
                                <div
                                    key={i}
                                    className={`aspect-square rounded-lg border border-white/5 transition-all duration-500 hover:scale-110 ${Math.random() > 0.4 ? 'bg-green-500/20' : 'bg-white/5'
                                        }`}
                                />
                            ))}
                        </div>
                        <div className="mt-8 flex justify-between items-center text-[8px] font-black uppercase text-zinc-600 tracking-widest">
                            <span>LOW EFFORT</span>
                            <div className="flex gap-1.5">
                                <div className="w-2.5 h-2.5 rounded-sm bg-white/5" />
                                <div className="w-2.5 h-2.5 rounded-sm bg-green-500/20" />
                                <div className="w-2.5 h-2.5 rounded-sm bg-green-500/40" />
                                <div className="w-2.5 h-2.5 rounded-sm bg-green-500/60" />
                            </div>
                            <span>BEAST MODE</span>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
}

function StatCard({ label, value, sub, icon }: any) {
    return (
        <motion.div
            whileHover={{ y: -5 }}
            className="glass-panel p-6 border border-white/5 bg-black/40"
        >
            <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-white/5 rounded-lg border border-white/10">{icon}</div>
                <span className="text-[10px] font-black uppercase tracking-widest text-text-muted">{label}</span>
            </div>
            <div className="text-3xl font-black text-white italic tracking-tighter mb-1">{value}</div>
            <div className="text-[10px] font-bold text-text-muted uppercase tracking-widest leading-tight">{sub}</div>
        </motion.div>
    );
}

function Card({ title, icon, children }: any) {
    return (
        <div className="glass-panel p-8 bg-black/40 border border-white/5">
            <h3 className="text-sm font-black text-white italic uppercase flex items-center gap-2 mb-2">
                {icon} {title}
            </h3>
            <div className="w-full h-px bg-white/5 mb-6" />
            {children}
        </div>
    );
}
