import { useState, useEffect } from 'react';
import { QrCode, Copy, ExternalLink, RefreshCw, Star, CheckCircle2, Trophy, Store } from 'lucide-react';
import { motion } from 'framer-motion';
import REVIEWS from '../data/gymReviews.json';
import { toast } from 'sonner';

export default function ReviewHubPage() {
    const [view, setView] = useState<'admin' | 'customer'>('admin');
    const [randomReview, setRandomReview] = useState('');
    const [targetUrl, setTargetUrl] = useState('https://maps.app.goo.gl/EoatxPKih7iD5WzM7?g_st=ipc');
    // Pre-fill with the active tunnel URL for immediate mobile access
    const [publicUrl, setPublicUrl] = useState('https://curvy-tables-cheat.loca.lt');

    // For QR Generation
    const displayUrl = publicUrl || (typeof window !== 'undefined' ? `${window.location.origin}/review-hub` : '');
    const qrData = `${displayUrl}${displayUrl.includes('?') ? '&' : '?'}mode=customer`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(qrData)}`;

    const isTablet = typeof window !== 'undefined' && window.innerWidth >= 768 && window.innerWidth < 1024;

    useEffect(() => {
        // Detect customer mode from URL params
        const params = new URLSearchParams(window.location.search);
        if (params.get('mode') === 'customer') {
            setView('customer');
            const randomIndex = Math.floor(Math.random() * REVIEWS.length);
            setRandomReview(REVIEWS[randomIndex]);
        }
    }, []);

    const refreshReview = () => {
        const randomIndex = Math.floor(Math.random() * REVIEWS.length);
        setRandomReview(REVIEWS[randomIndex]);
    };

    const handleCopyAndGo = () => {
        navigator.clipboard.writeText(randomReview);
        toast.success("Hệ thống đã sao chép nội dung!", {
            description: "Đang tự động chuyển hướng tới Google Maps..."
        });

        setTimeout(() => {
            window.location.href = targetUrl;
        }, 800);
    };

    if (view === 'customer') {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-[#030014] text-center" data-device="mobile">
                <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="w-24 h-24 bg-primary/20 rounded-[2rem] flex items-center justify-center mb-10 shadow-2xl shadow-primary/20"
                >
                    <Trophy className="text-primary" size={48} strokeWidth={3} />
                </motion.div>

                <div className="mb-12">
                    <h1 className="text-4xl font-[900] text-white italic tracking-tighter uppercase leading-none mb-4">CẢM ƠN BẠN!</h1>
                    <p className="text-zinc-500 font-bold uppercase tracking-widest text-xs px-10">Sự đánh giá của bạn là động lực để chúng tôi nâng tầm dịch vụ.</p>
                </div>

                <div className="w-full max-w-sm bg-zinc-900/40 p-10 rounded-[3rem] border border-white/5 backdrop-blur-3xl relative overflow-hidden group mb-10 shadow-2xl">
                    <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-primary via-accent to-primary animate-pulse" />

                    <div className="flex justify-center gap-1.5 mb-8">
                        {[1, 2, 3, 4, 5].map(i => (
                            <Star key={i} size={28} className="text-yellow-400 fill-yellow-400" />
                        ))}
                    </div>

                    <div className="bg-black/40 rounded-[2rem] p-8 border border-white/5 mb-10 italic">
                        <p className="text-lg font-bold text-zinc-300 leading-relaxed italic">
                            "{randomReview || REVIEWS[0]}"
                        </p>
                    </div>

                    <div className="space-y-6">
                        <button
                            onClick={handleCopyAndGo}
                            className="w-full py-6 bg-primary text-white font-[900] rounded-[2rem] shadow-2xl shadow-primary/40 italic uppercase tracking-[0.2em] active:scale-95 transition-all text-sm"
                        >
                            <Copy size={20} className="inline mr-2" strokeWidth={3} /> SAO CHÉP & ĐÁNH GIÁ 5⭐
                        </button>

                        <div className="p-5 bg-primary/5 rounded-[1.5rem] border border-primary/20 flex items-start gap-4 text-left">
                            <div className="w-8 h-8 rounded-xl bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                                <span className="text-xs font-black text-primary italic">!</span>
                            </div>
                            <p className="text-[10px] text-zinc-500 font-bold leading-relaxed uppercase tracking-wide">
                                <span className="text-primary font-black">HƯỚNG DẪN:</span> SAU KHI NHẤN NÚT TRÊN, BẠN CHỈ CẦN <span className="text-white font-black">CHẠM GIỮ</span> VÀO Ô NHẬN XÉT VÀ CHỌN <span className="text-white font-black">DÁN (PASTE)</span>.
                            </p>
                        </div>
                    </div>

                    <button
                        onClick={refreshReview}
                        className="mt-8 flex items-center gap-3 text-[10px] font-black text-zinc-600 hover:text-white mx-auto transition-all uppercase tracking-widest"
                    >
                        <RefreshCw size={14} strokeWidth={3} /> Đổi nội dung khác
                    </button>
                </div>

                <p className="text-[10px] text-zinc-700 uppercase tracking-[0.5em] font-black">
                    POWERED BY ANTIGRAVITY ENGINE
                </p>
            </div>
        );
    }


    return (
        <div className={`space-y-12 animate-fade-in pb-32 bg-[#030014] ${isTablet ? 'p-8' : 'p-12'}`} data-device={isTablet ? 'tablet' : 'desktop'}>
            {/* Admin Header */}
            <div className={`flex flex-col md:flex-row justify-between items-start md:items-end gap-8 border-b border-white/5 pb-10`}>
                <div>
                    <h1 className={`${isTablet ? 'text-5xl' : 'text-7xl'} font-[900] text-white italic tracking-tighter uppercase leading-none mb-4`}>REVIEW <span className="text-primary">HUB</span></h1>
                    <p className="text-zinc-500 font-bold uppercase tracking-[0.3em]">Hệ thống quản lý trải nghiệm khách hàng đa kênh</p>
                </div>
                <button
                    onClick={() => setView('customer')}
                    className="px-8 py-5 bg-zinc-900 border border-white/10 rounded-[2rem] text-[11px] font-black text-white hover:bg-zinc-800 transition-all active:scale-95 uppercase tracking-widest flex items-center gap-3 shadow-2xl"
                >
                    <ExternalLink size={18} strokeWidth={3} /> TRUY CẬP MOBILE VIEW
                </button>
            </div>

            <div className={`grid ${isTablet ? 'grid-cols-1' : 'lg:grid-cols-12'} gap-12`}>
                {/* QR Generation Card */}
                <div className={`${isTablet ? '' : 'lg:col-span-5'} space-y-8`}>
                    <div className="glass-panel p-10 bg-zinc-900/30 border border-white/5 rounded-[3rem] space-y-10 shadow-2xl">
                        <div className="flex items-center gap-4">
                            <div className="w-14 h-14 rounded-[1.5rem] bg-primary/20 flex items-center justify-center shadow-2xl shadow-primary/20">
                                <QrCode className="text-primary" size={28} strokeWidth={3} />
                            </div>
                            <h3 className="font-[900] text-2xl text-white italic uppercase">MÃ QR ĐÁNH GIÁ</h3>
                        </div>

                        <div className="bg-white p-10 rounded-[3rem] shadow-2xl max-w-xs mx-auto border-[12px] border-zinc-900 transition-transform duration-500 hover:scale-[1.05]">
                            <img src={qrUrl} alt="QR Code" className="w-full h-auto" />
                        </div>

                        <div className="space-y-6">
                            <div className="p-6 bg-black/40 rounded-[2rem] border border-white/5">
                                <p className="text-[10px] font-black text-zinc-600 uppercase mb-3 tracking-widest">GOOGLE MAPS TARGET URL</p>
                                <div className="flex gap-4">
                                    <input
                                        type="text"
                                        value={targetUrl}
                                        onChange={(e) => setTargetUrl(e.target.value)}
                                        className="flex-1 bg-transparent border-none outline-none text-sm font-bold text-white placeholder:text-zinc-800"
                                    />
                                    <Store size={20} className="text-primary" strokeWidth={3} />
                                </div>
                            </div>

                            <div className="p-6 bg-black/40 rounded-[2rem] border border-white/5">
                                <p className="text-[10px] font-black text-zinc-600 uppercase mb-3 tracking-widest">PUBLIC DEPLOYMENT LINK</p>
                                <div className="flex gap-4">
                                    <input
                                        type="text"
                                        placeholder="https://your-site.com/review-hub"
                                        value={publicUrl}
                                        onChange={(e) => setPublicUrl(e.target.value)}
                                        className="flex-1 bg-transparent border-none outline-none text-sm font-bold text-white placeholder:text-zinc-800"
                                    />
                                    <ExternalLink size={20} className="text-primary" strokeWidth={3} />
                                </div>
                            </div>

                            <div className="flex gap-4">
                                <button className="flex-1 py-5 bg-primary text-white font-[900] rounded-[1.5rem] shadow-2xl shadow-primary/30 italic uppercase tracking-widest active:scale-95 transition-all text-[11px]" onClick={() => window.print()}>
                                    IN MÃ QR
                                </button>
                                <button className="flex-1 py-5 bg-zinc-800 text-white font-[900] rounded-[1.5rem] italic uppercase tracking-widest active:scale-95 transition-all text-[11px]" onClick={() => {
                                    navigator.clipboard.writeText(qrData);
                                    toast.success("Đã sao chép link QR!");
                                }}>
                                    COPY LINK
                                </button>
                            </div>
                        </div>

                        <div className="p-6 rounded-[2rem] bg-blue-500/5 border border-blue-500/10">
                            <p className="text-[11px] text-blue-400 font-bold leading-relaxed uppercase tracking-wide">
                                <span className="text-blue-300 font-black">AI INSIGHT:</span> IN MÃ QR VÀ DÁN TẠI KHU VỰC CHỜ. KHI KHÁCH HÀNG QUÉT, HỆ THỐNG SẼ TỰ ĐỘNG CHỌN NGẪU NHIÊN 1 TRONG 100 MẪU ĐÁNH GIÁ ĐỂ TỐI ƯU HÓA SEO GOOGLE MAPS.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Reviews List Preview */}
                <div className={`${isTablet ? '' : 'lg:col-span-7'} flex flex-col`}>
                    <div className="glass-panel p-10 bg-zinc-900/30 border border-white/5 rounded-[3rem] flex flex-col h-full shadow-2xl">
                        <div className="flex items-center justify-between mb-10">
                            <div className="flex items-center gap-4">
                                <div className="w-14 h-14 rounded-[1.5rem] bg-green-500/20 flex items-center justify-center shadow-2xl shadow-green-500/20">
                                    <CheckCircle2 className="text-green-500" size={28} strokeWidth={3} />
                                </div>
                                <h3 className="font-[900] text-2xl text-white italic uppercase">THƯ VIỆN NỘI DUNG</h3>
                            </div>
                            <span className="px-6 py-2 bg-primary/10 rounded-full text-[10px] font-black text-primary border border-primary/20 uppercase tracking-widest">
                                {REVIEWS.length} MẪU CÓ SẴN
                            </span>
                        </div>

                        <div className="flex-1 overflow-y-auto no-scrollbar space-y-6 max-h-[1000px] pr-4">
                            {REVIEWS.map((review, idx) => (
                                <div key={idx} className="p-8 bg-black/40 rounded-[2.5rem] border border-white/5 hover:border-primary/40 transition-all duration-300 cursor-default group hover:scale-[1.01]">
                                    <div className="flex items-center gap-3 mb-4">
                                        <div className="flex gap-1">
                                            {[1, 2, 3, 4, 5].map(s => <Star key={s} size={12} className="text-primary fill-primary" />)}
                                        </div>
                                        <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">TEMPLATE #{idx + 1}</span>
                                    </div>
                                    <p className="text-[15px] font-bold text-zinc-400 group-hover:text-white transition-colors leading-relaxed italic">
                                        "{review}"
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
