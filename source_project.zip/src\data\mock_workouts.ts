export const WORKOUT_PROGRAMS = [
    {
        id: 'leg_hyper',
        name: 'Leg Hypertrophy',
        level: 'Hard',
        duration: '75m',
        focus: 'Quads & Glutes',
        description: 'High volume leg destruction. Focus on controlling the eccentric.',
        cover: 'https://images.unsplash.com/photo-1574680096141-1cddd32e04ca?w=600&q=80',
        exercises: [
            { id: 'sq_bb', name: 'Barbell Squat', sets: 4, reps: '6-8', type: 'COMPOUND' },
            { id: 'lp_mach', name: 'Leg Press', sets: 3, reps: '10-12', type: 'COMPOUND' },
            { id: 'rdl_bb', name: 'Romanian Deadlift', sets: 3, reps: '8-10', type: 'COMPOUND' },
            { id: 'le_mach', name: 'Leg Extension', sets: 3, reps: '15-20', type: 'ISOLATION' },
            { id: 'lc_mach', name: 'Leg Curl', sets: 3, reps: '12-15', type: 'ISOLATION' },
            { id: 'cr_std', name: 'Calf Raise', sets: 4, reps: '15-20', type: 'ISOLATION' }
        ]
    },
    {
        id: 'push_strength',
        name: 'Push Strength',
        level: 'Expert',
        duration: '60m',
        focus: 'Chest & Shoulders',
        description: 'Heavy loads to build raw pushing power.',
        cover: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=600&q=80',
        exercises: [
            { id: 'bp_bb', name: 'Bench Press', sets: 5, reps: '3-5', type: 'COMPOUND' },
            { id: 'ohp_bb', name: 'Overhead Press', sets: 4, reps: '4-6', type: 'COMPOUND' },
            { id: 'inc_db', name: 'Incline DB Press', sets: 3, reps: '8-10', type: 'COMPOUND' },
            { id: 'lat_raise', name: 'Lateral Raise', sets: 4, reps: '12-15', type: 'ISOLATION' },
            { id: 'tri_pd', name: 'Tricep Pushdown', sets: 3, reps: '12-15', type: 'ISOLATION' }
        ]
    },
    {
        id: 'pull_vol',
        name: 'Pull Volume',
        level: 'Medium',
        duration: '55m',
        focus: 'Back & Biceps',
        description: 'V-Taper building blocks.',
        cover: 'https://images.unsplash.com/photo-1598266663439-2056e6900339?w=600&q=80',
        exercises: [
            { id: 'dl_bb', name: 'Deadlift', sets: 3, reps: '5', type: 'COMPOUND' },
            { id: 'pull_up', name: 'Pull Ups', sets: 3, reps: 'AMRAP', type: 'COMPOUND' },
            { id: 'row_bb', name: 'Barbell Row', sets: 4, reps: '8-10', type: 'COMPOUND' },
            { id: 'lat_pd', name: 'Lat Pulldown', sets: 3, reps: '10-12', type: 'COMPOUND' },
            { id: 'bc_bb', name: 'Barbell Curl', sets: 3, reps: '10-12', type: 'ISOLATION' }
        ]
    }
];
