import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { addDays, subDays, format, isSameDay, parseISO } from 'date-fns';

export interface CheckInRecord {
    id: string;
    date: string; // ISO String
    type: 'Class' | 'PT' | 'Gym Access';
    trainerName?: string;
    note?: string;
    duration?: number; // phút tập
}

export interface Contract {
    id: string;
    code: string;
    packageName: string;
    startDate: string;
    endDate: string;
    status: 'Valid' | 'Expired' | 'Terminated';
    fileUrl: string; // Mock URL
}

export interface ScheduleItem {
    id: string;
    title: string;
    start: string; // ISO String
    end: string;   // ISO String
    trainer: string;
    type: 'Group Class' | 'PT Session';
    attendees: string[]; // Member IDs
    maxAttendees: number;
    resourceId?: string; // Room or Area
}

// === CHỈ SỐ SỨC KHỎE ===
export interface HealthMetrics {
    id: string;
    recordDate: string;     // Ngày đo
    recordedBy: string;     // PT/Staff đo

    // Chỉ số cơ bản
    weight: number;         // kg
    height?: number;        // cm (đo 1 lần)
    bmi?: number;           // tính tự động
    bodyFat?: number;       // % mỡ
    muscleMass?: number;    // % cơ

    // Số đo vòng (cm)
    chest?: number;
    waist?: number;
    hips?: number;
    thigh?: number;
    arm?: number;

    // Chỉ số thể lực
    restingHeartRate?: number;
    bloodPressure?: string; // "120/80"

    // Ghi chú PT
    notes?: string;
}

export interface Member {
    id: string;
    name: string;
    phone: string;
    email: string;
    avatar: string;

    // Membership Info
    joinDate: string;
    membershipType: string;
    status: 'Active' | 'Expired' | 'Pending';

    // Session Tracking
    sessionsTotal: number;
    sessionsUsed: number;
    lastCheckIn: string;

    // Extensions
    assignedPT?: string;
    faceIdRegistered: boolean;
    totalSpending: number;
    notes?: string;

    // Automation Engine Fields
    expiryDate?: string;        // Ngày hết hạn thẻ
    registrationDate?: string;  // Ngày đăng ký (= joinDate nếu không có)
    dateOfBirth?: string;       // Ngày sinh

    // Health & Fitness Goals
    fitnessGoals?: string[];    // ['Giảm cân', 'Tăng cơ', 'Giữ form']
    riskLevel?: 'low' | 'medium' | 'high';
    progressScore?: number;     // -100 to +100

    // Sub-data
    checkInHistory: CheckInRecord[];
    contracts: Contract[];
    healthMetrics?: HealthMetrics[];
}


interface MemberStore {
    members: Member[];
    schedule: ScheduleItem[];
    addMember: (member: any) => void;
    updateMember: (id: string, updates: Partial<Member>) => void;
    deleteMember: (id: string) => void;

    // Actions
    performCheckIn: (memberId: string, type: 'Class' | 'PT' | 'Gym Access', trainer?: string, note?: string) => void;
    addScheduleItem: (item: ScheduleItem) => void;
}

export const useMemberStore = create<MemberStore>()(
    persist(
        (set) => ({
            members: [
                {
                    id: 'MEM-001',
                    name: 'Nguyễn Văn An',
                    phone: '0901234567',
                    email: 'an.nguyen@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Felix',
                    joinDate: format(subDays(new Date(), 365), 'yyyy-MM-dd'),
                    membershipType: 'Gói 100 Buổi',
                    status: 'Active',
                    sessionsTotal: 100,
                    sessionsUsed: 42,
                    lastCheckIn: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
                    assignedPT: 'Coach HTS',
                    faceIdRegistered: true,
                    totalSpending: 15000000,
                    dateOfBirth: format(new Date(1990, new Date().getMonth(), new Date().getDate()), 'yyyy-MM-dd'), // SINH NHẬT HÔM NAY!
                    expiryDate: format(addDays(new Date(), 300), 'yyyy-MM-dd'),
                    registrationDate: '2025-01-15',
                    fitnessGoals: ['Tăng cơ', 'Giảm mỡ'],
                    progressScore: 85,
                    riskLevel: 'low',
                    healthMetrics: [
                        { id: 'HM-1-1', recordDate: format(new Date(), 'yyyy-MM-dd'), recordedBy: 'Coach HTS', weight: 70, height: 175, bmi: 22.8, bodyFat: 15, muscleMass: 45, chest: 100, waist: 76, hips: 92, notes: 'Đạt mục tiêu tháng này!' },
                        { id: 'HM-1-2', recordDate: format(subDays(new Date(), 15), 'yyyy-MM-dd'), recordedBy: 'Coach HTS', weight: 71, height: 175, bmi: 23.1, bodyFat: 16, muscleMass: 44, chest: 99, waist: 77, hips: 93, notes: 'Giảm mỡ tốt' },
                        { id: 'HM-1-3', recordDate: format(subDays(new Date(), 30), 'yyyy-MM-dd'), recordedBy: 'Coach HTS', weight: 72.5, height: 175, bmi: 23.6, bodyFat: 17.5, muscleMass: 43, chest: 98, waist: 78, hips: 94, notes: 'Cần cardio thêm' },
                        { id: 'HM-1-4', recordDate: format(subDays(new Date(), 60), 'yyyy-MM-dd'), recordedBy: 'Coach HTS', weight: 74, height: 175, bmi: 24.1, bodyFat: 19, muscleMass: 42, chest: 97, waist: 80, hips: 95, notes: 'Bắt đầu siết' },
                        { id: 'HM-1-5', recordDate: format(subDays(new Date(), 90), 'yyyy-MM-dd'), recordedBy: 'Coach HTS', weight: 76, height: 175, bmi: 24.8, bodyFat: 21, muscleMass: 40, chest: 96, waist: 82, hips: 96, notes: 'Bắt đầu tập luyện' }
                    ],
                    checkInHistory: [
                        { id: 'ci-101', date: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), type: 'Gym Access', note: 'Tự tập', duration: 90 },
                        { id: 'ci-102', date: format(subDays(new Date(), 1), 'yyyy-MM-dd') + 'T18:00:00', type: 'PT', trainerName: 'Coach HTS', note: 'Leg Day', duration: 60 },
                        { id: 'ci-103', date: format(subDays(new Date(), 2), 'yyyy-MM-dd') + 'T07:00:00', type: 'Gym Access', note: 'Cardio', duration: 45 },
                        { id: 'ci-104', date: format(subDays(new Date(), 3), 'yyyy-MM-dd') + 'T17:00:00', type: 'PT', trainerName: 'Coach HTS', note: 'Chest Day', duration: 60 },
                        { id: 'ci-105', date: format(subDays(new Date(), 5), 'yyyy-MM-dd') + 'T08:00:00', type: 'Gym Access', note: 'Back Day', duration: 75 },
                        { id: 'ci-106', date: format(subDays(new Date(), 6), 'yyyy-MM-dd') + 'T16:00:00', type: 'Class', trainerName: 'Zumba Master', note: 'Zumba', duration: 45 }
                    ],
                    contracts: []
                },
                {
                    id: 'MEM-002',
                    name: 'Bùi Tiến Dũng',
                    phone: '0988777666',
                    email: 'dung.bui@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Leo',
                    joinDate: format(subDays(new Date(), 365), 'yyyy-MM-dd'),
                    membershipType: 'Gói 30 Buổi',
                    status: 'Expired', // Đã hết buổi
                    sessionsTotal: 30,
                    sessionsUsed: 30,
                    lastCheckIn: format(subDays(new Date(), 1), 'yyyy-MM-dd') + 'T15:00:00',
                    faceIdRegistered: true,
                    totalSpending: 12000000,
                    dateOfBirth: '1992-05-10',
                    expiryDate: format(new Date(), 'yyyy-MM-dd'), // Hết hạn HÔM NAY
                    progressScore: 10,
                    riskLevel: 'medium',
                    checkInHistory: [],
                    contracts: [],
                    healthMetrics: []
                },
                {
                    id: 'MEM-003',
                    name: 'Trần Thị Bảo Ngọc',
                    phone: '0918765432',
                    email: 'ngoc.tran@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Aneka',
                    joinDate: format(subDays(new Date(), 100), 'yyyy-MM-dd'),
                    membershipType: 'Gói 12 Buổi',
                    status: 'Expired',
                    sessionsTotal: 12,
                    sessionsUsed: 12,
                    lastCheckIn: format(subDays(new Date(), 10), 'yyyy-MM-dd') + 'T10:00:00',
                    faceIdRegistered: false,
                    totalSpending: 4500000,
                    dateOfBirth: '1995-03-15',
                    expiryDate: format(subDays(new Date(), 3), 'yyyy-MM-dd'), // Hết hạn 3 ngày trước
                    progressScore: -25, // Negative
                    riskLevel: 'high',
                    fitnessGoals: ['Giảm cân', 'Fit body'],
                    healthMetrics: [
                        { id: 'HM-003-1', recordDate: format(subDays(new Date(), 10), 'yyyy-MM-dd'), recordedBy: 'Staff', weight: 58, height: 162, bmi: 22.1, bodyFat: 28, muscleMass: 30, notes: 'Cần tăng cơ' },
                        { id: 'HM-003-2', recordDate: format(subDays(new Date(), 40), 'yyyy-MM-dd'), recordedBy: 'Staff', weight: 56, height: 162, bmi: 21.3, bodyFat: 26, muscleMass: 29, notes: 'Có cải thiện' }
                    ],
                    checkInHistory: [],
                    contracts: []
                },
                {
                    id: 'MEM-004',
                    name: 'Lê Hoàng Dũng',
                    phone: '0989123123',
                    email: 'dung.le@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Jake',
                    joinDate: format(subDays(new Date(), 170), 'yyyy-MM-dd'),
                    membershipType: 'Gói 30 Buổi',
                    status: 'Active',
                    sessionsTotal: 30,
                    sessionsUsed: 5,
                    lastCheckIn: format(subDays(new Date(), 1), 'yyyy-MM-dd') + 'T17:00:00',
                    assignedPT: 'Coach Lyra',
                    faceIdRegistered: true,
                    totalSpending: 8500000,
                    dateOfBirth: '1988-07-22',
                    expiryDate: format(addDays(new Date(), 3), 'yyyy-MM-dd'), // Sắp hết hạn (3 ngày nữa)
                    fitnessGoals: ['Giảm cân'],
                    progressScore: 35,
                    riskLevel: 'low',
                    healthMetrics: [
                        { id: 'HM-4-1', recordDate: format(subDays(new Date(), 2), 'yyyy-MM-dd'), recordedBy: 'Coach Lyra', weight: 82, height: 178, bmi: 25.9, bodyFat: 22, muscleMass: 38, waist: 88, notes: 'Giảm 2kg' },
                        { id: 'HM-4-2', recordDate: format(subDays(new Date(), 30), 'yyyy-MM-dd'), recordedBy: 'Coach Lyra', weight: 84, height: 178, bmi: 26.5, bodyFat: 24, muscleMass: 36, waist: 92, notes: 'Bắt đầu' }
                    ],
                    checkInHistory: [
                        { id: 'ci-401', date: format(subDays(new Date(), 1), 'yyyy-MM-dd') + 'T17:00:00', type: 'PT', trainerName: 'Coach Lyra', note: 'Full body', duration: 60 },
                        { id: 'ci-402', date: format(subDays(new Date(), 2), 'yyyy-MM-dd') + 'T18:30:00', type: 'Gym Access', note: 'Cardio', duration: 40 },
                        { id: 'ci-403', date: format(subDays(new Date(), 4), 'yyyy-MM-dd') + 'T07:30:00', type: 'Gym Access', note: 'Weights', duration: 50 }
                    ],
                    contracts: []
                },
                {
                    id: 'MEM-005',
                    name: 'Phạm Minh Tuấn',
                    phone: '0977888999',
                    email: 'tuan.pham@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Ryan',
                    joinDate: format(subDays(new Date(), 1), 'yyyy-MM-dd'), // Mới tham gia hôm qua
                    membershipType: 'Gói 100 Buổi',
                    status: 'Active',
                    sessionsTotal: 100,
                    sessionsUsed: 1,
                    lastCheckIn: new Date().toISOString(),
                    faceIdRegistered: true,
                    totalSpending: 800000,
                    expiryDate: format(addDays(new Date(), 29), 'yyyy-MM-dd'),
                    // dateOfBirth: MISSING để test
                    checkInHistory: [],
                    contracts: [{ id: 'ct-4', code: 'HD-2024-010', packageName: 'Basic Month', startDate: '2024-01-05', endDate: '2024-02-05', status: 'Valid', fileUrl: '#' }],
                    healthMetrics: []
                },
                {
                    id: 'MEM-006',
                    name: 'Đỗ Quang Huy',
                    phone: '0905123987',
                    email: 'huy.do@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Brian',
                    joinDate: format(subDays(new Date(), 200), 'yyyy-MM-dd'),
                    membershipType: 'Gói 100 Buổi',
                    status: 'Active',
                    sessionsTotal: 100,
                    sessionsUsed: 98,
                    lastCheckIn: new Date(Date.now() - 86400000).toISOString(),
                    faceIdRegistered: true,
                    totalSpending: 7000000,
                    dateOfBirth: '1993-08-15',
                    expiryDate: format(addDays(new Date(), 60), 'yyyy-MM-dd'),
                    progressScore: 60,
                    riskLevel: 'low',
                    healthMetrics: [],
                    checkInHistory: [
                        { id: 'ci-601', date: new Date(Date.now() - 86400000).toISOString(), type: 'Gym Access', note: 'Morning routine', duration: 60 },
                        { id: 'ci-602', date: format(subDays(new Date(), 3), 'yyyy-MM-dd') + 'T19:00:00', type: 'Gym Access', note: 'Heavy lifts', duration: 75 },
                        { id: 'ci-603', date: format(subDays(new Date(), 5), 'yyyy-MM-dd') + 'T06:00:00', type: 'Gym Access', note: 'Cardio', duration: 30 }
                    ],
                    contracts: []
                },
                {
                    id: 'MEM-007',
                    name: 'Ngô Thanh Vân',
                    phone: '0912000111',
                    email: 'van.ngo@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Julia',
                    joinDate: format(subDays(new Date(), 40), 'yyyy-MM-dd'),
                    membershipType: 'Gói 30 Buổi',
                    status: 'Active',
                    sessionsTotal: 30,
                    sessionsUsed: 25,
                    lastCheckIn: format(subDays(new Date(), 5), 'yyyy-MM-dd'),
                    assignedPT: 'Coach Sarah',
                    faceIdRegistered: true,
                    totalSpending: 6000000,
                    dateOfBirth: '1996-12-01',
                    expiryDate: format(addDays(new Date(), 50), 'yyyy-MM-dd'),
                    checkInHistory: [
                        { id: 'ci-701', date: format(subDays(new Date(), 0), 'yyyy-MM-dd') + 'T09:00:00', type: 'Class', trainerName: 'Coach Sarah', note: 'Yoga', duration: 60 },
                        { id: 'ci-702', date: format(subDays(new Date(), 2), 'yyyy-MM-dd') + 'T10:00:00', type: 'PT', trainerName: 'Coach Sarah', note: 'Core training', duration: 45 },
                        { id: 'ci-703', date: format(subDays(new Date(), 4), 'yyyy-MM-dd') + 'T17:30:00', type: 'Class', trainerName: 'Yoga Master', note: 'Pilates', duration: 50 }
                    ],
                    contracts: []
                },
                {
                    id: 'MEM-008',
                    name: 'Hoàng Thùy Linh',
                    phone: '0944555666',
                    email: 'linh.hoang@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Eliza',
                    joinDate: format(subDays(new Date(), 15), 'yyyy-MM-dd'),
                    membershipType: 'Gói 100 Buổi',
                    status: 'Active',
                    sessionsTotal: 100,
                    sessionsUsed: 16,
                    lastCheckIn: new Date().toISOString(),
                    faceIdRegistered: false,
                    totalSpending: 9000000,
                    dateOfBirth: '1998-02-14',
                    expiryDate: format(addDays(new Date(), 165), 'yyyy-MM-dd'),
                    checkInHistory: [{ id: 'ci-901', date: new Date().toISOString(), type: 'Class', trainerName: 'Zumba Master', note: 'Zumba Class' }],
                    contracts: [],
                    // NEW HEALTH DATA
                    healthMetrics: [
                        { id: 'HM-8-1', recordDate: format(new Date(), 'yyyy-MM-dd'), recordedBy: 'Coach Mike', weight: 48, height: 160, bmi: 18.7, bodyFat: 20, muscleMass: 36, notes: 'Cần tăng cân nhẹ' }
                    ]
                },
                {
                    id: 'MEM-009',
                    name: 'Vũ Thị Hạnh',
                    phone: '0933444555',
                    email: 'hanh.vu@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Maria',
                    joinDate: format(subDays(new Date(), 5), 'yyyy-MM-dd'),
                    membershipType: 'Gói 12 Buổi',
                    status: 'Pending', // Pending payment
                    sessionsTotal: 12,
                    sessionsUsed: 0,
                    lastCheckIn: 'N/A',
                    faceIdRegistered: false,
                    totalSpending: 0,
                    dateOfBirth: '2000-05-05',
                    expiryDate: format(addDays(new Date(), 25), 'yyyy-MM-dd'),
                    checkInHistory: [],
                    contracts: []
                },
                {
                    id: 'MEM-010',
                    name: 'Trương Thế Vinh',
                    phone: '0966777888',
                    email: 'vinh.truong@example.com',
                    avatar: 'https://api.dicebear.com/9.x/avataaars/svg?seed=Nolan',
                    joinDate: format(subDays(new Date(), 360), 'yyyy-MM-dd'),
                    membershipType: 'Gói 100 Buổi',
                    status: 'Expired',
                    sessionsTotal: 100,
                    sessionsUsed: 100,
                    lastCheckIn: format(subDays(new Date(), 200), 'yyyy-MM-dd'),
                    faceIdRegistered: true,
                    totalSpending: 5000000,
                    dateOfBirth: '1989-10-20',
                    expiryDate: format(subDays(new Date(), 60), 'yyyy-MM-dd'), // Expired 2 months ago
                    checkInHistory: [],
                    contracts: []
                }
            ],
            schedule: [
                { id: 'sch-1', title: 'Yoga Morning', start: new Date().setHours(6, 0, 0, 0) + '', end: new Date().setHours(7, 0, 0, 0) + '', trainer: 'Sarah', type: 'Group Class', attendees: [], maxAttendees: 15 },
                { id: 'sch-2', title: 'PT Session - HTS', start: new Date().setHours(9, 0, 0, 0) + '', end: new Date().setHours(10, 0, 0, 0) + '', trainer: 'Coach HTS', type: 'PT Session', attendees: ['mem-001'], maxAttendees: 1 },
                { id: 'sch-3', title: 'Zumba Dance', start: new Date().setHours(17, 30, 0, 0) + '', end: new Date().setHours(18, 30, 0, 0) + '', trainer: 'Zumba Master', type: 'Group Class', attendees: ['MEM-009'], maxAttendees: 20 },
                { id: 'sch-4', title: 'Body Pump', start: new Date().setHours(18, 0, 0, 0) + '', end: new Date().setHours(19, 0, 0, 0) + '', trainer: 'Coach Mike', type: 'Group Class', attendees: [], maxAttendees: 20 },
                { id: 'sch-5', title: 'PT Session - Lyra', start: new Date().setHours(15, 0, 0, 0) + '', end: new Date().setHours(16, 0, 0, 0) + '', trainer: 'Coach Lyra', type: 'PT Session', attendees: ['MEM-003'], maxAttendees: 1 }
            ],

            addMember: (data) => set((state) => ({
                members: [
                    ...state.members,
                    {
                        id: `mem-${Date.now()}`,
                        joinDate: new Date().toISOString(),
                        lastCheckIn: 'N/A',
                        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.name}`,
                        faceIdRegistered: false,
                        totalSpending: 0,
                        sessionsTotal: 30,
                        sessionsUsed: 0,
                        checkInHistory: [],
                        contracts: [],
                        ...data
                    }
                ]
            })),

            updateMember: (id, updates) => set((state) => ({
                members: state.members.map((m) => m.id === id ? { ...m, ...updates } : m)
            })),

            deleteMember: (id) => set((state) => ({
                members: state.members.filter((m) => m.id !== id)
            })),

            performCheckIn: (memberId, type, trainer, note) => set((state) => {
                const memberIndex = state.members.findIndex(m => m.id === memberId);
                if (memberIndex === -1) return state;

                const member = state.members[memberIndex];
                const now = new Date();

                // 1. Rule: Một ngày chỉ được điểm danh 1 lần
                if (member.lastCheckIn && member.lastCheckIn !== 'N/A') {
                    if (isSameDay(parseISO(member.lastCheckIn), now)) {
                        // Đã điểm danh hôm nay
                        return state;
                    }
                }

                // 2. Rule: Kiểm tra số buổi còn lại
                if (member.sessionsUsed >= member.sessionsTotal) {
                    return state; // Hết buổi tập
                }

                // 3. Thực hiện điểm danh và trừ buổi
                const newHistory = {
                    id: `ci-${Date.now()}`,
                    date: now.toISOString(),
                    type: type || 'Gym Access',
                    trainerName: trainer,
                    note
                };

                const updatedMember = {
                    ...member,
                    sessionsUsed: member.sessionsUsed + 1,
                    lastCheckIn: now.toISOString(),
                    checkInHistory: [newHistory, ...member.checkInHistory],
                    status: (member.sessionsUsed + 1 >= member.sessionsTotal) ? 'Expired' : member.status
                };

                const newMembers = [...state.members];
                newMembers[memberIndex] = updatedMember;

                return { members: newMembers };
            }),
            addScheduleItem: (item) => set((state) => ({
                schedule: [...state.schedule, item]
            }))
        }),
        {
            name: 'member-storage-v5' // Updated to force reload with new check-in data
        }
    )
);
