import { useState } from 'react';
import { useBoardStore } from '../store/useBoardStore';
import type { Task } from '../store/useBoardStore';
import { motion, AnimatePresence } from 'framer-motion';
import { Target, Plus, Check, Zap, User, Briefcase, Trash2, ListFilter } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function WorkPage() {
    const { tasks: tasksMap, columnOrder, addTask, toggleTaskCompletion, deleteTask } = useBoardStore();
    const tasks = Object.values(tasksMap);
    const [newTaskText, setNewTaskText] = useState('');
    const [category, setCategory] = useState<Task['category']>('work');
    const [showAddSheet, setShowAddSheet] = useState(false);
    const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const isTablet = typeof window !== 'undefined' && window.innerWidth >= 768 && window.innerWidth < 1024;

    const handleAdd = (e: any) => {
        e.preventDefault();
        if (!newTaskText.trim()) return;
        const firstCol = columnOrder[0];
        addTask(firstCol, newTaskText, category);
        setNewTaskText('');
        setShowAddSheet(false);
        toast.success('ĐÃ TẠO NHIỆM VỤ', { description: 'Nhiệm vụ mới đã được thêm vào danh sách.' });
    };

    const stats = {
        total: tasks.length,
        completed: tasks.filter(t => t.completed).length,
        pending: tasks.filter(t => !t.completed).length,
    };

    const filteredTasks = tasks.filter(t => {
        if (filter === 'pending') return !t.completed;
        if (filter === 'completed') return t.completed;
        return true;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // ========== MOBILE VIEW ==========
    if (isMobile) {
        return (
            <div className="flex flex-col min-h-full bg-[#030014] pb-32" data-device="mobile">
                {/* Header Stats */}
                <div className="px-6 pt-8 pb-4">
                    <h1 className="text-3xl font-[900] text-white italic uppercase tracking-tighter mb-6">WORK<span className="text-primary">FLOW</span></h1>
                    <div className="grid grid-cols-2 gap-4">
                        <motion.div
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="bg-zinc-900/40 border border-white/5 rounded-[2rem] p-5 shadow-2xl"
                        >
                            <div className="flex items-center gap-3 mb-3">
                                <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-500">
                                    <Check size={18} strokeWidth={3} />
                                </div>
                                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">DONE</span>
                            </div>
                            <span className="text-4xl font-[900] text-white italic">{stats.completed}</span>
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="bg-zinc-900/40 border border-white/5 rounded-[2rem] p-5 shadow-2xl"
                        >
                            <div className="flex items-center gap-3 mb-3">
                                <div className="p-2 bg-primary/10 rounded-xl text-primary">
                                    <Target size={18} strokeWidth={3} />
                                </div>
                                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">NEXT</span>
                            </div>
                            <span className="text-4xl font-[900] text-white italic">{stats.pending}</span>
                        </motion.div>
                    </div>
                </div>

                {/* Filter Tabs */}
                <div className="px-6 mb-6">
                    <div className="flex gap-2 p-1.5 bg-zinc-900/60 rounded-[1.5rem] border border-white/5">
                        {(['all', 'pending', 'completed'] as const).map((f) => (
                            <button
                                key={f}
                                onClick={() => setFilter(f)}
                                className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all ${filter === f
                                    ? 'bg-primary text-white shadow-xl shadow-primary/40'
                                    : 'text-zinc-500'
                                    }`}
                            >
                                {f === 'all' ? 'Tất Cả' : f === 'pending' ? 'Chờ' : 'Xong'}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Task List */}
                <div className="flex-1 px-6 space-y-4 no-scrollbar pb-10">
                    <AnimatePresence mode="popLayout">
                        {filteredTasks.length === 0 ? (
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                className="py-20 text-center flex flex-col items-center justify-center gap-4"
                            >
                                <div className="w-20 h-20 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-800">
                                    <Check size={40} />
                                </div>
                                <p className="text-zinc-600 font-bold uppercase tracking-widest text-xs">Không có nhiệm vụ nào</p>
                            </motion.div>
                        ) : (
                            filteredTasks.map((task, idx) => (
                                <motion.div
                                    key={task.id}
                                    layout
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.9 }}
                                    transition={{ delay: idx * 0.05 }}
                                    className={`relative group bg-[#0a0a0f] border border-white/5 rounded-[2.5rem] p-5 shadow-2xl transition-all ${task.completed ? 'opacity-40' : 'hover:border-primary/20'}`}
                                >
                                    <div className="flex items-center gap-5">
                                        {/* Custom Checkbox */}
                                        <button
                                            onClick={() => toggleTaskCompletion(task.id)}
                                            className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all shrink-0 ${task.completed
                                                ? 'bg-emerald-500 border-emerald-500 shadow-lg shadow-emerald-500/20'
                                                : 'border-zinc-800 active:scale-90 bg-black/40'
                                                }`}
                                        >
                                            {task.completed && <Check size={18} className="text-black" strokeWidth={4} />}
                                        </button>

                                        {/* Content Area */}
                                        <div className="flex-1 min-w-0 pr-10">
                                            <div className="flex items-center gap-2 mb-1.5">
                                                <div className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider ${task.priority === 'urgent' ? 'bg-red-500/20 text-red-500' :
                                                    task.priority === 'high' ? 'bg-orange-500/20 text-orange-500' :
                                                        'bg-primary/20 text-primary'
                                                    }`}>
                                                    {task.priority}
                                                </div>
                                                <div className="w-1 h-1 rounded-full bg-zinc-800" />
                                                <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">
                                                    {format(new Date(task.date), 'dd/MM')}
                                                </span>
                                            </div>
                                            <p className={`text-[15px] font-bold leading-tight ${task.completed ? 'line-through text-zinc-600' : 'text-zinc-100'}`}>
                                                {task.content}
                                            </p>
                                        </div>

                                        {/* Actions */}
                                        <button
                                            onClick={() => deleteTask(task.id)}
                                            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center text-zinc-800 hover:text-red-500 active:scale-95 transition-all"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </motion.div>
                            ))
                        )}
                    </AnimatePresence>
                </div>

                {/* FAB */}
                <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowAddSheet(true)}
                    className="fixed bottom-24 right-6 w-16 h-16 bg-primary rounded-[2rem] flex items-center justify-center text-white shadow-[0_20px_50px_rgba(168,85,247,0.4)] z-[90] border-4 border-[#030014]"
                >
                    <Plus size={30} strokeWidth={3} />
                </motion.button>

                {/* Bottom Sheet Modal */}
                <AnimatePresence>
                    {showAddSheet && (
                        <>
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowAddSheet(false)} className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100]" />
                            <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }} className="fixed bottom-0 left-0 right-0 bg-[#0c0c0e] rounded-t-[3rem] z-[101] border-t border-white/10 p-8">
                                <div className="flex justify-center mb-6"><div className="w-12 h-1.5 bg-zinc-800 rounded-full" /></div>
                                <form onSubmit={handleAdd} className="space-y-6">
                                    <h3 className="text-2xl font-[900] text-white italic uppercase tracking-tighter">Mục Tiêu Mới</h3>
                                    <textarea value={newTaskText} onChange={(e) => setNewTaskText(e.target.value)} placeholder="Nhập nội dung công việc..." className="w-full h-32 bg-zinc-900 border border-white/5 rounded-[2rem] p-6 text-white text-lg font-bold placeholder-zinc-700 outline-none focus:border-primary/50 resize-none no-scrollbar" autoFocus />
                                    <div className="grid grid-cols-3 gap-3">
                                        <CategoryBtn active={category === 'work'} onClick={() => setCategory('work')} icon={<Briefcase size={22} />} label="Work" />
                                        <CategoryBtn active={category === 'personal'} onClick={() => setCategory('personal')} icon={<User size={22} />} label="Personal" />
                                        <CategoryBtn active={category === 'life'} onClick={() => setCategory('life')} icon={<Zap size={22} />} label="Life" />
                                    </div>
                                    <div className="flex gap-4 pt-4">
                                        <button type="submit" className="flex-1 py-5 bg-primary text-white font-[900] rounded-[2rem] shadow-2xl shadow-primary/40 uppercase italic tracking-widest text-lg">XÁC NHẬN</button>
                                    </div>
                                </form>
                            </motion.div>
                        </>
                    )}
                </AnimatePresence>
            </div>
        );
    }

    // ========== TABLET VIEW ==========
    if (isTablet) {
        return (
            <div className="flex flex-col h-full bg-[#030014] text-white overflow-hidden" data-device="tablet">
                <div className="flex-1 overflow-y-auto p-8 space-y-8 no-scrollbar">
                    <div className="flex items-end justify-between">
                        <h1 className="text-5xl font-[900] italic uppercase leading-tight tracking-tighter">Work<span className="text-primary">flow</span></h1>
                        <div className="flex gap-4">
                            <StatBox label="Completed" value={stats.completed} color="text-emerald-500" icon={<Check size={20} />} />
                            <StatBox label="Active" value={stats.pending} color="text-primary" icon={<Target size={20} />} />
                        </div>
                    </div>

                    <div className="grid grid-cols-12 gap-8">
                        {/* LEFT: Management Console */}
                        <div className="col-span-4 space-y-8">
                            <div className="p-8 rounded-[3rem] bg-zinc-900/40 border border-white/5 flex flex-col items-center shadow-2xl">
                                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em] mb-8">Daily Achievement</span>
                                <div className="relative w-40 h-40">
                                    <svg className="w-full h-full transform -rotate-90">
                                        <circle cx="80" cy="80" r="72" strokeWidth="12" stroke="rgba(255,255,255,0.03)" fill="transparent" />
                                        <circle
                                            cx="80" cy="80" r="72" strokeWidth="12" stroke="currentColor" fill="transparent"
                                            strokeDasharray={2 * Math.PI * 72}
                                            strokeDashoffset={2 * Math.PI * 72 * (1 - (stats.completed / (stats.total || 1)))}
                                            className="text-primary transition-all duration-1000 ease-out"
                                            strokeLinecap="round"
                                        />
                                    </svg>
                                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                                        <span className="text-4xl font-[900] italic leading-none">{Math.round((stats.completed / (stats.total || 1)) * 100)}%</span>
                                    </div>
                                </div>
                            </div>

                            <div className="p-8 rounded-[3rem] bg-zinc-900/20 border border-white/5 space-y-6">
                                <h3 className="text-sm font-black uppercase tracking-widest text-zinc-400">Add New Goal</h3>
                                <form onSubmit={handleAdd} className="space-y-4">
                                    <textarea value={newTaskText} onChange={(e) => setNewTaskText(e.target.value)} placeholder="Drafting project X..." className="w-full h-32 bg-zinc-900 border border-white/5 rounded-[2rem] p-5 text-white font-bold outline-none focus:border-primary/50 resize-none" />
                                    <div className="grid grid-cols-3 gap-2">
                                        <CategoryBtn active={category === 'work'} onClick={() => setCategory('work')} icon={<Briefcase size={18} />} label="Work" />
                                        <CategoryBtn active={category === 'personal'} onClick={() => setCategory('personal')} icon={<User size={18} />} label="Personal" />
                                        <CategoryBtn active={category === 'life'} onClick={() => setCategory('life')} icon={<Zap size={18} />} label="Life" />
                                    </div>
                                    <button type="submit" className="w-full py-4 bg-primary rounded-[1.5rem] font-black uppercase italic tracking-widest shadow-xl shadow-primary/20 transition-all active:scale-95">Push to List</button>
                                </form>
                            </div>
                        </div>

                        {/* RIGHT: Task Stream */}
                        <div className="col-span-8 space-y-6">
                            <div className="flex gap-4 p-1.5 bg-zinc-900/60 rounded-[2rem] border border-white/5">
                                {(['all', 'pending', 'completed'] as const).map((f) => (
                                    <button key={f} onClick={() => setFilter(f)} className={`flex-1 py-4 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all ${filter === f ? 'bg-zinc-800 text-white shadow-xl' : 'text-zinc-600 hover:text-zinc-400'}`}>
                                        {f === 'all' ? 'All Stream' : f === 'pending' ? 'Active' : 'Archived'}
                                    </button>
                                ))}
                            </div>

                            <div className="space-y-4 no-scrollbar">
                                <AnimatePresence mode="popLayout">
                                    {filteredTasks.map((task) => (
                                        <TaskItem key={task.id} task={task} onToggle={toggleTaskCompletion} onDelete={deleteTask} />
                                    ))}
                                </AnimatePresence>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // ========== DESKTOP VIEW ==========
    return (
        <div className="space-y-8 pb-24 relative text-white">
            {/* Background Decoration */}
            <div className="fixed inset-0 pointer-events-none bg-neutral-950 -z-10" />

            {/* Header / Command Center */}
            <div className="flex flex-col md:flex-row items-end justify-between gap-8 pb-8 border-b border-neutral-800 relative z-10 pt-4">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-blue-600/20 rounded-lg text-blue-500">
                            <Briefcase size={20} />
                        </div>
                        <span className="text-sm font-bold text-blue-500 uppercase tracking-wider">Workspace</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight">
                        Tasks & <span className="text-neutral-500">Priorities</span>
                    </h1>
                </div>

                <div className="flex gap-4">
                    <StatBox label="Completed" value={stats.completed} color="text-green-500" icon={<Check size={16} />} />
                    <StatBox label="Pending" value={stats.pending} color="text-orange-500" icon={<Target size={16} />} />
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 relative z-10">
                {/* Left: Input Console */}
                <div className="lg:col-span-4 space-y-6">
                    <div className="bg-[#09090b] border border-neutral-800 rounded-3xl p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-white mb-6 flex items-center gap-2">
                            <Plus size={18} className="text-blue-500" /> New Task
                        </h3>
                        <form onSubmit={handleAdd} className="space-y-5">
                            <div className="space-y-2">
                                <label className="text-xs font-semibold text-neutral-500 pl-1">What needs to be done?</label>
                                <textarea
                                    value={newTaskText}
                                    onChange={(e) => setNewTaskText(e.target.value)}
                                    placeholder="Draft proposal, Review code, etc..."
                                    className="w-full h-32 bg-neutral-900 border border-neutral-800 rounded-xl p-4 text-white placeholder-neutral-600 outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/50 transition-all font-medium text-sm resize-none"
                                />
                            </div>

                            <div className="space-y-2">
                                <label className="text-xs font-semibold text-neutral-500 pl-1">Category</label>
                                <div className="grid grid-cols-3 gap-2">
                                    <CategoryBtn active={category === 'work'} onClick={() => setCategory('work')} icon={<Briefcase size={16} />} label="Work" color="blue" />
                                    <CategoryBtn active={category === 'personal'} onClick={() => setCategory('personal')} icon={<User size={16} />} label="Personal" color="purple" />
                                    <CategoryBtn active={category === 'life'} onClick={() => setCategory('life')} icon={<Zap size={16} />} label="Life" color="green" />
                                </div>
                            </div>

                            <button type="submit" className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-semibold text-sm transition-all shadow-lg shadow-blue-900/20 active:scale-[0.98]">
                                Add Task to Queue
                            </button>
                        </form>
                    </div>

                    <div className="bg-blue-500/5 border border-blue-500/10 rounded-2xl p-5 flex items-start gap-4">
                        <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500 shrink-0">
                            <Zap size={18} />
                        </div>
                        <div>
                            <p className="text-xs font-bold text-blue-400 uppercase tracking-widest mb-1">Pro Tip</p>
                            <p className="text-sm font-medium text-neutral-400 leading-relaxed">Break down complex tasks into smaller, actionable steps to maintain momentum.</p>
                        </div>
                    </div>
                </div>

                {/* Right: Task Stream */}
                <div className="lg:col-span-8 space-y-6">
                    <div className="flex items-center justify-between px-2">
                        <div className="flex items-center gap-2">
                            <ListFilter size={18} className="text-neutral-500" />
                            <span className="text-sm font-semibold text-neutral-400">Task List</span>
                        </div>
                        <span className="text-xs font-medium text-neutral-600 uppercase tracking-wider">{tasks.length} Items</span>
                    </div>

                    <div className="space-y-3">
                        <AnimatePresence mode="popLayout">
                            {tasks.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((task) => (
                                <TaskItem
                                    key={task.id}
                                    task={task}
                                    onToggle={toggleTaskCompletion}
                                    onDelete={(id) => deleteTask(id)}
                                />
                            ))}
                        </AnimatePresence>
                        {tasks.length === 0 && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-24 border-2 border-dashed border-neutral-800 rounded-3xl">
                                <div className="w-16 h-16 bg-neutral-900 rounded-full flex items-center justify-center mx-auto mb-4 text-neutral-700">
                                    <Check size={32} />
                                </div>
                                <p className="text-neutral-500 font-medium">All tasks completed. Great job!</p>
                            </motion.div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

function StatBox({ label, value, color, icon }: any) {
    return (
        <div className="flex items-center gap-4 px-5 py-3 bg-[#09090b] border border-neutral-800 rounded-2xl min-w-[140px]">
            <div className={`p-2 rounded-lg bg-neutral-900 ${color}`}>
                {icon}
            </div>
            <div className="flex flex-col">
                <span className="text-xs font-medium text-neutral-500 uppercase tracking-wide">{label}</span>
                <span className="text-xl font-bold text-white tabular-nums">{value}</span>
            </div>
        </div>
    );
}

function CategoryBtn({ active, onClick, icon, label }: any) {
    const inactiveClass = "bg-neutral-900 border-neutral-800 text-neutral-500 hover:bg-neutral-800/80 hover:text-neutral-300";

    // Fallback for dynamic classes in Tailwind (safelist common colors or stick to specific styles)
    // Here simplifying logic for consistent styling
    const isActiveWork = active && label === 'Work';
    const isActivePersonal = active && label === 'Personal';
    const isActiveLife = active && label === 'Life';

    let finalClass = inactiveClass;
    if (isActiveWork) finalClass = "bg-blue-500/20 border-blue-500/50 text-blue-400 ring-1 ring-blue-500/20";
    if (isActivePersonal) finalClass = "bg-purple-500/20 border-purple-500/50 text-purple-400 ring-1 ring-purple-500/20";
    if (isActiveLife) finalClass = "bg-green-500/20 border-green-500/50 text-green-400 ring-1 ring-green-500/20";

    return (
        <button
            type="button"
            onClick={onClick}
            className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all duration-200 ${finalClass}`}
        >
            {icon}
            <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
        </button>
    );
}

function TaskItem({ task, onToggle, onDelete }: { task: Task, onToggle: (id: string) => void, onDelete: (id: string) => void }) {
    const translatePriority = (p: string) => {
        const map: Record<string, string> = { 'urgent': 'Urgent', 'high': 'High', 'medium': 'Medium', 'low': 'Low' };
        return map[p] || p;
    };

    const translateCategory = (c: string) => {
        const map: Record<string, string> = { 'work': 'Work', 'personal': 'Personal', 'life': 'Life' };
        return map[c] || c;
    };

    const priorityColors: Record<string, string> = {
        'urgent': 'text-red-400 bg-red-400/10 border-red-400/20',
        'high': 'text-orange-400 bg-orange-400/10 border-orange-400/20',
        'medium': 'text-blue-400 bg-blue-400/10 border-blue-400/20',
        'low': 'text-green-400 bg-green-400/10 border-green-400/20'
    };

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.98, transition: { duration: 0.15 } }}
            className={`group relative bg-[#09090b] border rounded-2xl p-4 sm:p-5 flex items-start sm:items-center gap-4 transition-all duration-200 ${task.completed
                ? 'border-neutral-800 opacity-60'
                : 'border-neutral-800 hover:border-neutral-700 hover:shadow-lg'
                }`}
        >
            <button
                onClick={() => onToggle(task.id)}
                className={`shrink-0 w-6 h-6 rounded-full border flex items-center justify-center transition-all duration-200 mt-1 sm:mt-0 ${task.completed
                    ? 'bg-blue-500 border-blue-500 text-black'
                    : 'border-neutral-600 hover:border-blue-500 text-transparent'
                    }`}
            >
                <Check size={14} strokeWidth={3} />
            </button>

            <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${priorityColors[task.priority] || 'text-neutral-400 bg-neutral-800 border-neutral-700'}`}>
                        {translatePriority(task.priority)}
                    </span>
                    <span className="text-[10px] font-semibold text-neutral-500 uppercase flex items-center gap-1">
                        <span className="w-1 h-1 rounded-full bg-neutral-600" />
                        {translateCategory(task.category)}
                    </span>
                    <span className="text-[10px] text-neutral-600 font-medium ml-auto sm:ml-0">
                        {format(new Date(task.date), 'MMM dd')}
                    </span>
                </div>
                <p className={`text-base sm:text-lg transition-all ${task.completed
                    ? 'line-through text-neutral-600 font-medium'
                    : 'text-neutral-200 font-medium'
                    }`}>
                    {task.content}
                </p>
            </div>

            <button
                onClick={() => onDelete(task.id)}
                className="opacity-0 group-hover:opacity-100 p-2 text-neutral-500 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all absolute right-4 top-1/2 -translate-y-1/2"
            >
                <Trash2 size={18} />
            </button>
        </motion.div>
    );
}
