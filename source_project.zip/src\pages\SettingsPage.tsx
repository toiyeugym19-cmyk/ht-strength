import { useState } from 'react';
import { useNutritionStore } from '../store/useNutritionStore';
import { AutomationSettings, AutomationLogs } from '../components/AutomationPanel';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import {
    Settings as SettingsIcon,
    User,
    Shield,
    Database,
    Save,
    RotateCcw,
    Cpu,
    Zap
} from 'lucide-react';

export default function SettingsPage() {
    const { goals, updateGoals } = useNutritionStore();
    const [localGoals, setLocalGoals] = useState({ ...goals });
    const [activeTab, setActiveTab] = useState('profile');

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const isTablet = typeof window !== 'undefined' && window.innerWidth >= 768 && window.innerWidth < 1024;

    const handleSaveGoals = () => {
        updateGoals(localGoals);
        toast.success("Đã cập nhật mục tiêu dinh dưỡng!");
    };

    return (
        <div className={`max-w-7xl mx-auto pb-32 ${isMobile ? 'px-6 pt-10' : isTablet ? 'p-8' : 'p-12'}`} data-device={isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop'}>
            {/* Header */}
            <div className="mb-12">
                <h1 className="text-4xl font-[900] text-white italic tracking-tighter uppercase mb-4 flex items-center gap-4">
                    <SettingsIcon className="text-primary" size={isMobile ? 32 : 40} strokeWidth={3} /> SETTINGS <span className="text-zinc-600">HUB</span>
                </h1>
                <p className="text-zinc-500 font-bold uppercase tracking-[0.3em] text-[10px] pl-1">
                    CƠ SỞ HẠ TẦNG & CẤU HÌNH HỆ THỐNG
                </p>
            </div>

            <div className={`grid ${isMobile ? 'grid-cols-1' : 'lg:grid-cols-12'} gap-12`}>
                {/* Tabs Area */}
                <div className={`${isMobile ? 'flex overflow-x-auto no-scrollbar gap-4 pb-4 border-b border-white/5' : 'lg:col-span-3 space-y-2'}`}>
                    <TabItem
                        icon={<User size={18} strokeWidth={3} />}
                        label="Hồ Sơ"
                        active={activeTab === 'profile'}
                        onClick={() => setActiveTab('profile')}
                        isMobile={isMobile}
                    />
                    <TabItem
                        icon={<Cpu size={18} strokeWidth={3} />}
                        label="Automation"
                        active={activeTab === 'automation'}
                        onClick={() => setActiveTab('automation')}
                        isMobile={isMobile}
                    />
                    <TabItem
                        icon={<Database size={18} strokeWidth={3} />}
                        label="Dữ Liệu"
                        active={activeTab === 'system'}
                        onClick={() => setActiveTab('system')}
                        isMobile={isMobile}
                    />
                    <TabItem
                        icon={<Shield size={18} strokeWidth={3} />}
                        label="Bảo Mật"
                        active={activeTab === 'security'}
                        onClick={() => setActiveTab('security')}
                        isMobile={isMobile}
                    />
                </div>

                {/* Content Area */}
                <div className={`${isMobile ? '' : 'lg:col-span-9'} space-y-8`}>

                    {/* --- PROFILE TAB --- */}
                    {activeTab === 'profile' && (
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                            <section className="bg-zinc-900/20 border border-white/5 rounded-[2.5rem] p-10 space-y-10 relative overflow-hidden group">
                                <div className="absolute top-0 left-0 w-1.5 h-full bg-primary/20" />
                                <div>
                                    <h3 className="text-2xl font-[900] text-white italic uppercase tracking-tighter mb-2">MỤC TIÊU DINH DƯỠNG</h3>
                                    <p className="text-[10px] font-black text-zinc-600 uppercase tracking-widest leading-relaxed">Cấu hình chỉ số Macro metabolism hàng ngày cho AI Tracker.</p>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-3">
                                        <label className="text-[9px] font-black text-zinc-500 uppercase tracking-widest pl-1">CALORIES / NGÀY</label>
                                        <input
                                            type="number"
                                            className="w-full bg-black/40 border border-white/5 rounded-2xl px-6 py-4 text-sm font-bold text-white focus:border-primary focus:outline-none transition-all"
                                            value={localGoals.dailyCalories}
                                            onChange={e => setLocalGoals({ ...localGoals, dailyCalories: Number(e.target.value) })}
                                        />
                                    </div>
                                    <div className="space-y-3">
                                        <label className="text-[9px] font-black text-blue-500 uppercase tracking-widest pl-1">PROTEIN (GRAM)</label>
                                        <input
                                            type="number"
                                            className="w-full bg-black/40 border border-white/5 rounded-2xl px-6 py-4 text-sm font-bold text-white focus:border-blue-500 focus:outline-none transition-all"
                                            value={localGoals.protein}
                                            onChange={e => setLocalGoals({ ...localGoals, protein: Number(e.target.value) })}
                                        />
                                    </div>
                                    <div className="space-y-3">
                                        <label className="text-[9px] font-black text-orange-500 uppercase tracking-widest pl-1">CARBS (GRAM)</label>
                                        <input
                                            type="number"
                                            className="w-full bg-black/40 border border-white/5 rounded-2xl px-6 py-4 text-sm font-bold text-white focus:border-orange-500 focus:outline-none transition-all"
                                            value={localGoals.carbs}
                                            onChange={e => setLocalGoals({ ...localGoals, carbs: Number(e.target.value) })}
                                        />
                                    </div>
                                    <div className="space-y-3">
                                        <label className="text-[9px] font-black text-green-500 uppercase tracking-widest pl-1">FAT (GRAM)</label>
                                        <input
                                            type="number"
                                            className="w-full bg-black/40 border border-white/5 rounded-2xl px-6 py-4 text-sm font-bold text-white focus:border-green-500 focus:outline-none transition-all"
                                            value={localGoals.fat}
                                            onChange={e => setLocalGoals({ ...localGoals, fat: Number(e.target.value) })}
                                        />
                                    </div>
                                </div>

                                <div className="pt-4 flex justify-end">
                                    <button onClick={handleSaveGoals} className="flex items-center gap-3 px-10 py-5 bg-primary text-white rounded-[1.5rem] font-[900] text-[11px] italic uppercase tracking-[0.2em] shadow-2xl shadow-primary/30 active:scale-95 transition-all">
                                        <Save size={18} strokeWidth={3} /> LƯU CẤU HÌNH
                                    </button>
                                </div>
                            </section>
                        </motion.div>
                    )}

                    {/* --- AUTOMATION TAB --- */}
                    {activeTab === 'automation' && (
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-12">
                            <AutomationSettings />
                            <AutomationLogs />
                        </motion.div>
                    )}

                    {/* --- SYSTEM TAB --- */}
                    {activeTab === 'system' && (
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-12">
                            {/* Data Generator Section */}
                            <section className="bg-zinc-900/10 border border-green-500/20 rounded-[2.5rem] p-10 space-y-8 relative overflow-hidden group">
                                <div className="absolute top-0 right-0 p-10 opacity-[0.03] rotate-12 group-hover:rotate-0 transition-transform duration-700">
                                    <Zap size={200} />
                                </div>
                                <div className="relative z-10">
                                    <h3 className="text-2xl font-[900] text-green-500 italic uppercase tracking-tighter mb-2 flex items-center gap-3">
                                        <Zap size={24} strokeWidth={3} /> DATA GENERATOR
                                    </h3>
                                    <p className="text-[10px] font-black text-green-500/60 uppercase tracking-widest leading-relaxed">System Test Bench: Tạo dữ liệu giả lập cho môi trường Development.</p>
                                </div>

                                <div className="space-y-4 relative z-10">
                                    <GeneratorAction
                                        title="HỘI VIÊN MẪU (x50)"
                                        desc="Tạo 50 khách hàng với đầy đủ check-in, health metrics và hợp đồng."
                                        onClick={() => {
                                            import('../utils/dataGenerator').then(({ generateMembers }) => {
                                                const members = generateMembers(50);
                                                localStorage.setItem('generated-members', JSON.stringify(members));
                                                toast.success(`Đã tạo ${members.length} hội viên mẫu!`);
                                                window.location.reload();
                                            });
                                        }}
                                    />

                                    <GeneratorAction
                                        title="NHIỆM VỤ MẪU (x100)"
                                        desc="Tạo 100 task CRM: gọi điện, CSKH, gia hạn và follow-up."
                                        onClick={() => {
                                            import('../utils/dataGenerator').then(({ generateTasks }) => {
                                                const tasks = generateTasks(100);
                                                localStorage.setItem('generated-tasks', JSON.stringify(tasks));
                                                toast.success(`Đã tạo ${tasks.length} tasks mẫu!`);
                                            });
                                        }}
                                    />

                                    <button
                                        onClick={() => {
                                            import('../utils/dataGenerator').then(({ generateAllData }) => {
                                                const data = generateAllData();
                                                localStorage.setItem('member-storage-v5', JSON.stringify({
                                                    state: { members: data.members, schedule: data.schedule },
                                                    version: 0
                                                }));
                                                localStorage.setItem('member-automation-store-v1', JSON.stringify({
                                                    state: {
                                                        tasks: data.tasks,
                                                        logs: data.logs,
                                                        todayStats: data.todayStats,
                                                        plans: [],
                                                        isEngineRunning: true,
                                                        lastEngineRun: new Date().toISOString(),
                                                        n8nStatus: 'connected'
                                                    },
                                                    version: 0
                                                }));
                                                toast.success('🎉 TOÀN BỘ DỮ LIỆU ĐÃ ĐƯỢC KHOẢI TẠO!');
                                                setTimeout(() => window.location.reload(), 1000);
                                            });
                                        }}
                                        className="w-full p-8 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 text-white font-[900] text-sm italic uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl shadow-green-500/30 hover:scale-[1.02] active:scale-95 transition-all text-center"
                                    >
                                        INITIALIZE FULL ECOSYSTEM 🚀
                                    </button>
                                </div>
                            </section>

                            {/* Danger Zone */}
                            <section className="bg-red-500/5 border border-red-500/20 rounded-[2.5rem] p-10 space-y-6">
                                <div>
                                    <h3 className="text-2xl font-[900] text-red-500 italic uppercase tracking-tighter mb-2">DANGER ZONE</h3>
                                    <p className="text-[10px] font-black text-red-500/60 uppercase tracking-widest leading-relaxed">Hành động hủy diệt: Không thể hoàn tác dữ liệu sau khi thực hiện.</p>
                                </div>

                                <div className="flex items-center justify-between p-6 bg-black/40 rounded-2xl border border-red-500/10">
                                    <div>
                                        <h4 className="text-[13px] font-[900] text-white italic uppercase tracking-wider mb-1">Xóa Toàn Bộ Database</h4>
                                        <p className="text-[10px] text-zinc-600 font-bold uppercase">Clear localstorage & hard reset</p>
                                    </div>
                                    <button
                                        onClick={() => {
                                            if (confirm('BẠN CÓ CHẮC MUỐN XÓA SẠCH DỮ LIỆU CỦA ANTIGRAVITY OS?')) {
                                                localStorage.clear();
                                                window.location.reload();
                                            }
                                        }}
                                        className="p-4 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all border border-red-500/20 shadow-xl active:scale-90"
                                    >
                                        <RotateCcw size={20} strokeWidth={3} />
                                    </button>
                                </div>
                            </section>
                        </motion.div>
                    )}

                    {activeTab === 'security' && (
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col items-center justify-center py-32 text-center opacity-20">
                            <Shield size={100} strokeWidth={1} className="mb-10 text-zinc-500" />
                            <h3 className="text-2xl font-[900] text-white italic uppercase tracking-widest mb-4">SYSTEM PROTECTED</h3>
                            <p className="text-[10px] font-black uppercase tracking-[0.5em] text-zinc-500">Security modules are active and encrypted.</p>
                        </motion.div>
                    )}
                </div>
            </div>
        </div>
    );
}

function TabItem({ icon, label, active = false, onClick, isMobile }: any) {
    if (isMobile) {
        return (
            <button
                onClick={onClick}
                className={`shrink-0 px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${active ? 'bg-primary text-white shadow-xl shadow-primary/30 scale-105' : 'bg-zinc-900/50 text-zinc-600 hover:text-white'}`}
            >
                <div className="flex flex-col items-center gap-2">
                    {icon}
                    <span>{label}</span>
                </div>
            </button>
        );
    }
    return (
        <button
            onClick={onClick}
            className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all cursor-pointer font-[900] text-[11px] uppercase tracking-widest italic group ${active ? 'bg-primary text-white shadow-2xl shadow-primary/30 scale-[1.05] z-10' : 'text-zinc-600 hover:text-white hover:bg-white/5'}`}
        >
            <span className="shrink-0">{icon}</span>
            <span>{label}</span>
            {active && (
                <div className="ml-auto flex gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                </div>
            )}
        </button>
    );
}

function GeneratorAction({ title, desc, onClick }: any) {
    return (
        <div className="flex items-center justify-between p-6 bg-black/40 rounded-[2rem] border border-white/5 hover:border-green-500/20 transition-all group">
            <div className="flex-1 mr-6">
                <h4 className="text-[13px] font-[900] text-white italic uppercase tracking-wider mb-1 group-hover:text-green-500 transition-colors">{title}</h4>
                <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-wide leading-relaxed">{desc}</p>
            </div>
            <button
                onClick={onClick}
                className="px-6 py-3 bg-green-500/10 text-green-500 font-black text-[10px] italic hover:bg-green-500 hover:text-white rounded-xl transition-all border border-green-500/20 shadow-xl uppercase tracking-widest active:scale-95"
            >
                GENERATE
            </button>
        </div>
    );
}
