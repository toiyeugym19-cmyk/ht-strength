const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DkVRiuZ6.js","assets/index-DNLHt4hG.js","assets/index-DFogSOwU.css"])))=>i.map(i=>d[i]);
import{r as o,_ as t}from"./index-DNLHt4hG.js";const r=o("GoogleFit",{web:()=>t(()=>import("./web-DkVRiuZ6.js"),__vite__mapDeps([0,1,2])).then(e=>new e.GoogleFitWeb)});export{r as GoogleFit};
